﻿namespace SustainableForaging.Core.Models
{
    public enum Category
    {
        Edible,
        Medicinal,
        Inedible,
        Poisonous
    }
}
import React from 'react'
function mapToLi(list){
    return list.map((task) => {return <li>{task}</li>})
}
export default (props) => {
    return <ul>{mapToLi(props.list)}</ul>
}
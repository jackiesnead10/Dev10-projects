import React, {useState} from "react";

export default (props) => {
  const [newTask, setNewTask] = useState("");
  const handleChange = function(evt){
    let textValue = evt.target.value;
    setNewTask(textValue);
  }
  const handleSubmit = function(evt){
    evt.preventDefault();
    props.onNewTask(newTask);
    setNewTask("");
  }
  return (
    <form onSubmit={handleSubmit}>
      <p>{newTask}</p>
      <input id="newTask" type="text" value={newTask} onChange={handleChange}></input>
      <button type="submit" id="btnNewTask">Add Task</button>
    </form>
  );
};

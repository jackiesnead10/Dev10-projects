import React, {useState} from 'react'

import logo from './logo.svg';
import './App.css';
import TodoList from './components/Todolist';
import AddTodoItem from './components/AddTodoItem';

function App() {
  const [myData, setMyData] = useState(["Hello World", "Learning React"])
  const handleNewTask = (newTask) => {
    let data = [...myData, newTask];
    setMyData(data);
  }
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Randall's ToDo Application
        </p>
        <AddTodoItem onNewTask={handleNewTask}></AddTodoItem>
        <TodoList list={myData}></TodoList>
       
      </header>
    </div>
  );
}

export default App;

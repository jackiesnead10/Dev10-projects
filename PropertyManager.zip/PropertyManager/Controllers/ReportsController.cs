﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PropertyManager.CORE.Interfaces.DAL;
using PropertyManager.CORE;

namespace PropertyManager.Controllers
{
    [Route("/reports")]
    public class ReportsController : Controller
    {

        private IReportRepository reportRepository;
        private IPropertyRepository propertyRepository;


        public ReportsController(IReportRepository reportRepository, IPropertyRepository propertyRepository)
        {
            this.reportRepository = reportRepository;
            this.propertyRepository = propertyRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        [Route("/avgagepropertytype")]
        public IActionResult ViewAvgAgePerPropertyType()
        {
            var result = reportRepository.GetAverageAge();

            if (result.Success)
            {
                return View(result.Data);
            }
            else
            {
                return BadRequest(result.Message);
            }
        }

        [Route("/ViewAvgOffersIncomeOnProperty")]
        [HttpPost]
        public IActionResult ViewAvgOffersIncomeOnProperty(AverageIncomeForOffersOnProperty data)
        {
            var result = reportRepository.GetIncomeForProperty(data.PropertyId);
            

            if (result.Success)
            {
                var propertyDetails = propertyRepository.Get(data.PropertyId);

                result.Data.PropertyAddress = propertyDetails.Data.Address;
                result.Data.PropertyTotalPrice = propertyDetails.Data.TotalPrice.Value;
                result.Data.PropertyId = propertyDetails.Data.PropertyId;

                return View(result.Data);
            }
            else
            {
                return View("NoPropOffers");
            }
        }

    }
}

using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Tokens;
using PropertyManager.CORE;
using PropertyManager.CORE.Interfaces.DAL;
using PropertyManager.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyManager
{
    public class Startup
    {
        
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            string connection = ConfigManager.GetConnectionString();
            services.AddDbContext<PropertyManagerContext>(options => options.UseSqlServer(connection)
               .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking));
            services.AddTransient<IPropertyRepository, PropertyEFRepo>();
            services.AddTransient<IRenterPropertyRepository, RenterPropertyEFRepository>();
            services.AddTransient<IBuyerPropertyRepository, BuyerPropertyEFRepository>();
            services.AddTransient<IReportRepository, ReportEFRepo>();
            services.AddTransient<IUserRepository, UserEFRepo>();
            services.AddTransient<IOfferPropertyRepository, OfferPropertyEFRepo>();
            services.AddTransient<ILoginRepository, LoginEFRepository>();
            services.AddTransient<IOfferRepository, OfferEFRepo>();
            services.AddTransient<IOfferBuyerRepository, OfferBuyerEFRepo>();

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
         .AddJwtBearer(options =>
         {
             options.TokenValidationParameters = new TokenValidationParameters
             {
                 ValidateIssuer = true,
                 ValidateAudience = true,
                 ValidateLifetime = true,
                 ValidateIssuerSigningKey = true,

                 ValidIssuer = "http://localhost:7900",
                 ValidAudience = "http://localhost:7900",
                 IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("KeyForSignInSecret@1234"))
             };
             services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
         });


            
            services.AddCors(options => options.AddPolicy("corspolicy", (builder) =>
            {
                builder.AllowAnyMethod().AllowAnyHeader().AllowAnyOrigin();
            }));

           
          


            //AddNewtonsoftJson(...) is preventing endless loops when working with the Login entity in the UsersController. it stops the json serialization if it starts looping.
            services.AddControllersWithViews().AddNewtonsoftJson(x => x.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCors("corspolicy");
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}

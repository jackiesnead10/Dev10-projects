﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Linq;
using System.Threading.Tasks;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Identity.UI.V4.Pages.Account.Internal;
using PropertyManager.Models;
using PropertyManager.CORE.Entities;
using PropertyManager.CORE;
using PropertyManager.CORE.Interfaces.DAL;


namespace PropertyManager.APIControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly PropertyManagerContext context;
        private readonly ILoginRepository loginRepository;

        public AuthController(PropertyManagerContext context, ILoginRepository loginRepository)
        {
            this.context = context;
            this.loginRepository = loginRepository;
        }




        [HttpPost, Route("/api/auth/login")]
        public IActionResult Login(LoginsModel user)
        {
            if (user == null)
            {
                return BadRequest("Invalid request");
            }

            var loginResult = loginRepository.Get(user.UserName, user.Password);
            if (!loginResult.Success)
            {
                return Unauthorized();
            }


            var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("KeyForSignInSecret@1234"));
            var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);

            var tokeOptions = new JwtSecurityToken(
                issuer: "http://localhost:7900",
                audience: "http://localhost:7900",
                claims: new List<Claim>(),
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: signinCredentials
            );

            var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);
            return Ok(new { Token = tokenString, User = loginResult.Data.UserId });

        }
    }
}

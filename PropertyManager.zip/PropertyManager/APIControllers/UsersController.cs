﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PropertyManager.CORE;
using PropertyManager.CORE.Entities;

using PropertyManager.CORE.Interfaces.DAL;
using PropertyManager.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PropertyManager.APIControllers
{
    [ApiController]
    [Route("/api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly IUserRepository userRepository;
        private readonly ILoginRepository loginRepository;
        private readonly PropertyManagerContext context;

        public UsersController(IUserRepository userRepository, ILoginRepository loginRepository, PropertyManagerContext context)
        {
            this.userRepository = userRepository;
            this.loginRepository = loginRepository;
            this.context = context;
        }

        [HttpGet("{id}", Name ="GetUser")]
        public IActionResult Get(int id)
        {
            Result<User> result = userRepository.Get(id);

            if (!result.Success)
            {
                return BadRequest(result.Message);
            }

            var userLoginResult = loginRepository.GetByUser(id);
            if (!userLoginResult.Success)
            {
                return BadRequest($"Cannot find login info for user {id}");
            }

            UsersModel usersModel = new UsersModel
            {
                UserId = result.Data.UserId,
                FirstName = result.Data.FirstName,
                LastName = result.Data.LastName,
                Age = result.Data.Age,
                Income = result.Data.Income,
                FamilyType = result.Data.FamilyType,
                Email = result.Data.Email,
                Username = userLoginResult.Data.Username,
                Password = userLoginResult.Data.Password
            };

            return Ok(usersModel);
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            Result<List<User>> result = userRepository.GetAll();

            if (!result.Success)
            {
                return BadRequest(result.Message);
            }


            List<UsersModel> userModels = new List<UsersModel>();
            foreach (var user in result.Data)
            {

                var userLoginResult = loginRepository.GetByUser(user.UserId);
                if (!userLoginResult.Success)
                {
                    return BadRequest($"Cannot find login info for user {user.UserId}");
                }

                UsersModel userModel = new UsersModel
                {
                    UserId = user.UserId,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Age = user.Age,
                    Income = user.Income,
                    FamilyType = user.FamilyType,
                    Email = user.Email,
                    Username = userLoginResult.Data.Username,
                    Password = userLoginResult.Data.Password
                };

                userModels.Add(userModel);
            }


            return Ok(userModels);
        }

        [HttpPost]
        public IActionResult AddUser(UsersModel usersModel)
        {
            User user = new User
            {
                FirstName = usersModel.FirstName,
                LastName = usersModel.LastName,
                Age = usersModel.Age,
                Income = usersModel.Income,
                FamilyType = usersModel.FamilyType,
                Email = usersModel.Email
            };

            var userInsertResult = userRepository.Insert(user);
            if (!userInsertResult.Success)
            {
                return BadRequest(userInsertResult.Message);
            }

            Login login = new Login
            {
                Username = usersModel.Username,
                Password = usersModel.Password,
                UserId = userInsertResult.Data.UserId
            };

            var loginInsertResult = loginRepository.Insert(login);
            if (!loginInsertResult.Success)
            {
                userRepository.Delete(userInsertResult.Data.UserId);
                return BadRequest(loginInsertResult.Message);
            }
            return CreatedAtAction(nameof(Get), new { id = userInsertResult.Data.UserId }, user);
        }

        [HttpPut]
        public IActionResult EditUser(UsersModel usersModel)
        {
            User user = new User
            {
                UserId = (int)usersModel.UserId,
                FirstName = usersModel.FirstName,
                LastName = usersModel.LastName,
                Age = usersModel.Age,
                Income = usersModel.Income,
                FamilyType = usersModel.FamilyType,
                Email = usersModel.Email
            };

            var result = userRepository.Update(user);
            if (!result.Success)
            {
                return BadRequest(result.Message);
            }
            return Ok();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            if (!userRepository.Get(id).Success)
            {
                return NotFound($"User {id} not found");
            }

            var result = userRepository.Delete(id);
            if (!result.Success)
            {
                return BadRequest(result.Message);
            }
            return Ok();
        }
    }
}

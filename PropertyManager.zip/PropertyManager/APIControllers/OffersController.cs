﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PropertyManager.CORE;
using PropertyManager.CORE.Entities;
using PropertyManager.CORE.Interfaces.DAL;
using PropertyManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyManager.APIControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OffersController : ControllerBase
    {
        private readonly IOfferRepository offerRepository;
        private readonly IOfferPropertyRepository offerPropertyRepository;
        private readonly IOfferBuyerRepository offerBuyerRepository;
        private readonly PropertyManagerContext context;

        public OffersController(IOfferRepository offerRepository, IOfferPropertyRepository offerPropertyRepository,
            IOfferBuyerRepository offerBuyerRepository, PropertyManagerContext context)
        {
            this.offerRepository = offerRepository;
            this.offerPropertyRepository = offerPropertyRepository;
            this.offerBuyerRepository = offerBuyerRepository;
            this.context = context;
        }




        [HttpGet, Authorize]

        [Route("/api/[controller]/user/{id}", Name = "GetUserOffers")]
        public IActionResult GetUserOffers(int id)
        {
            var offerResult = offerRepository.GetByUser(id);

            if (!offerResult.Success)
            {
                return BadRequest(offerResult.Message);
            }

            List<OfferModel> offers = new List<OfferModel>();
            foreach (var item in offerResult.Data)
            {
                var offerPropertyResult = offerPropertyRepository.GetByOffer(item.OfferId);
                if (!offerPropertyResult.Success)
                {
                    return BadRequest(offerPropertyResult.Message);
                }

                OfferModel offerModel = new OfferModel
                {
                    Amount = item.Amount,
                    UserId = id,
                    OfferId = item.OfferId,
                    PropertyId = offerPropertyResult.Data.Where(op => op.OfferId == item.OfferId).FirstOrDefault().PropertyId
                };

                offers.Add(offerModel);
            }

            return Ok(offers);

        }

        [HttpPost, Authorize]
        public IActionResult AddOffer(OfferModel offerModel)
        {
            Offer offer = new Offer { Amount = offerModel.Amount };
            var offerInsertResult = offerRepository.Insert(offer);

            if (!offerInsertResult.Success)
            {
                return BadRequest(offerInsertResult.Message);
            }

            OfferProperty offerProperty = new OfferProperty
            {
                OfferId = offerInsertResult.Data.OfferId,
                PropertyId = offerModel.PropertyId
            };
            var offerPropertyInsertResult = offerPropertyRepository.Insert(offerProperty);

            if (!offerPropertyInsertResult.Success)
            {
                return BadRequest(offerPropertyInsertResult.Message);

            }

            OfferBuyer offerBuyer = new OfferBuyer
            {
                OfferId = offerInsertResult.Data.OfferId,
                UserId = offerModel.UserId
            };
            var offerBuyerInsertResult = offerBuyerRepository.Insert(offerBuyer);

            if (!offerBuyerInsertResult.Success)
            {
                return BadRequest(offerBuyerInsertResult.Message);
            }

            return Ok(
                new OfferModel
                {
                    OfferId = offerInsertResult.Data.OfferId,
                    Amount = offerInsertResult.Data.Amount,
                    UserId = offerModel.UserId,
                    PropertyId = offerModel.PropertyId
                });
        }

        [HttpPut, Authorize]
        public IActionResult Edit(OfferModel offerModel)
        {
            if (offerModel.OfferId == null)
            {
                return BadRequest("Offer ID cannot be null");
            }
            var offerGetResult = offerRepository.Get(offerModel.OfferId.Value);

            if (!offerGetResult.Success)
            {
                return BadRequest(offerGetResult.Message);
            }

            Offer offer = offerGetResult.Data;
            offer.Amount = offerModel.Amount;

            var editResult = offerRepository.Update(offer);

            if (!editResult.Success)
            {
                return BadRequest(editResult.Message);
            }

            return Ok();
        }

        [HttpDelete, Authorize]
        [Route("/api/[controller]/{offerId}")]
        public IActionResult Delete(int offerId)
        {

            var offerGetResult = offerRepository.Get(offerId);

            if (!offerGetResult.Success)
            {
                return BadRequest(offerGetResult.Message);
            }

            var deleteOfferResult = offerRepository.Delete(offerId);
            if (!deleteOfferResult.Success)
            {
                return BadRequest(deleteOfferResult.Message);
            }

            return Ok();

        }
    }
}

﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PropertyManager.CORE;
using PropertyManager.CORE.Entities;
using PropertyManager.CORE.Interfaces.DAL;
using PropertyManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyManager.APIControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PropertiesController : ControllerBase
    {
        private readonly IPropertyRepository _propertyRepository;
        private readonly PropertyManagerContext context;
        private readonly IRenterPropertyRepository renterPropertyRepository;
        private readonly IBuyerPropertyRepository buyerPropertyRepository;

        public PropertiesController(IPropertyRepository propertyRepository, PropertyManagerContext _context,
            IRenterPropertyRepository renterPropertyRepository, IBuyerPropertyRepository buyerPropertyRepository)
        {
            _propertyRepository = propertyRepository;
            context = _context;
            this.renterPropertyRepository = renterPropertyRepository;
            this.buyerPropertyRepository = buyerPropertyRepository;
        }

        [HttpGet]
        [Route("/api/[controller]"), Authorize]
        public IActionResult GetAllProperties()
        {
            var result = _propertyRepository.GetAll();



            if (result.Success)
            {
                List<PropertiesModel> pmodels = new List<PropertiesModel>();
                foreach (var property in result.Data)
                {
                    PropertiesModel propertiesModel = new PropertiesModel
                    {
                        PropertyId = property.PropertyId,
                        Description = context.PropertyType.FirstOrDefault(x => x.PropertyTypeId == property.PropertyTypeId).Description,
                        TotalPrice = property.TotalPrice,
                        RentPerMonth = property.RentPerMonth,
                        IsRented = property.IsRented,
                        Address = property.Address
                    };
                    pmodels.Add(propertiesModel);
                }

                return Ok(pmodels);

            }
            else
            {
                return BadRequest(result.Message);
            }

        }

        [HttpGet]
        [Route("/api/[controller]/{id}", Name = "GetProperty")]
        public IActionResult GetProperty(int id)
        {
            var result = _propertyRepository.Get(id);

            if (result.Success)
            {
                var property = result.Data;
                PropertiesModel propertiesModel = new PropertiesModel
                {
                    PropertyId = property.PropertyId,
                    Description = context.PropertyType.FirstOrDefault(x => x.PropertyTypeId == property.PropertyTypeId).Description,
                    TotalPrice = property.TotalPrice,
                    RentPerMonth = property.RentPerMonth,
                    IsRented = property.IsRented,
                    Address = property.Address
                };
                return Ok(propertiesModel);
            }
            else
            {
                return BadRequest(result.Message);
            }
        }

        [HttpGet, Authorize]
        [Route("/api/[controller]/user/{id}")]
        public IActionResult GetPropertiesByUser(int id)
        {
            var result = _propertyRepository.GetByUser(id);

            if (!result.Success)
            {
                return BadRequest(result.Message);
            }

            List<PropertiesModel> pmodels = new List<PropertiesModel>();
            foreach (var property in result.Data)
            {
                DateTime? leaseStartDate = null;
                DateTime? leaseEndDate = null;
                DateTime? dateOfSale = null;
                if (property.IsRented)
                {
                    var renterPropertyResult = renterPropertyRepository.GetByProperty(property.PropertyId);
                    if (!renterPropertyResult.Success)
                    {
                        return BadRequest(renterPropertyResult.Message);

                    }
                    RenterProperty renterProperty = renterPropertyResult.Data.FirstOrDefault(rp => rp.UserId == id);
                    leaseStartDate = renterProperty.LeaseStartDate;
                    leaseEndDate = renterProperty.LeaseEndDate;

                }
                else
                {
                    var buyerPropertyResult = buyerPropertyRepository.GetByProperty(property.PropertyId);
                    if (!buyerPropertyResult.Success)
                    {
                        return BadRequest(buyerPropertyResult.Message);
                    }
                    BuyerProperty buyerProperty = buyerPropertyResult.Data.FirstOrDefault(rp => rp.UserId == id);
                    dateOfSale = buyerProperty.DateOfPurchase;
                }

                PropertiesModel propertiesModel = new PropertiesModel
                {

                    PropertyId = property.PropertyId,
                    Description = context.PropertyType.FirstOrDefault(x => x.PropertyTypeId == property.PropertyTypeId).Description,
                    TotalPrice = property.TotalPrice,
                    RentPerMonth = property.RentPerMonth,
                    IsRented = property.IsRented,
                    Address = property.Address,
                    LeaseStartDate = leaseStartDate,
                    LeaseEndDate = leaseEndDate,
                    DateOfSale = dateOfSale,
                    UserId = id
                };
                pmodels.Add(propertiesModel);
            }
            return Ok(pmodels);
        }

        [HttpGet, Authorize]
        [Route("offer/{id}")]
        public IActionResult GetPropertyByOffer(int id)
        {
            var result = _propertyRepository.GetByOffer(id);

            if (!result.Success)
            {
                return BadRequest(result.Message);
            }

            var property = result.Data;
            


            PropertiesModel propertiesModel = new PropertiesModel
            {
                PropertyId = property.PropertyId,
                Description = context.PropertyType.FirstOrDefault(x => x.PropertyTypeId == property.PropertyTypeId).Description,
                TotalPrice = property.TotalPrice,
                RentPerMonth = property.RentPerMonth,
                IsRented = property.IsRented,
                Address = property.Address,
            };

            return Ok(propertiesModel);
        }

        [HttpPost, Authorize]
        public IActionResult AddProperty(PropertiesModel propertyModel)
        {
            if (propertyModel.UserId == null)
            {
                return Unauthorized();
            }
            Property property = new Property
            {
                PropertyTypeId = context.PropertyType.FirstOrDefault(x => x.Description == propertyModel.Description).PropertyTypeId,
                TotalPrice = propertyModel.TotalPrice,
                RentPerMonth = propertyModel.RentPerMonth,
                IsRented = propertyModel.IsRented,
                Address = propertyModel.Address

            };

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = _propertyRepository.Insert(property);
            if (!result.Success)
            {
                return BadRequest(result.Message);
            }

            int errorCount = 0;
            if (property.IsRented)
            {
                RenterProperty renterProperty = new RenterProperty
                {
                    PropertyId = result.Data.PropertyId,
                    UserId = (int)propertyModel.UserId,
                    LeaseStartDate = (DateTime)propertyModel.LeaseStartDate,
                    LeaseEndDate = (DateTime)propertyModel.LeaseEndDate,
                };
                errorCount = renterPropertyRepository.Insert(renterProperty).Success ? errorCount : errorCount++;
            }
            else
            {
                BuyerProperty buyerProperty = new BuyerProperty
                {
                    PropertyId = result.Data.PropertyId,
                    UserId = (int)propertyModel.UserId,
                    DateOfPurchase = (DateTime)propertyModel.DateOfSale
                };
                errorCount = buyerPropertyRepository.Insert(buyerProperty).Success ? errorCount : errorCount++;
            }

            if (errorCount > 0)
            {
                _propertyRepository.Delete(property.PropertyId);
                return BadRequest($"Cannot create property {property.PropertyId} with User id {propertyModel.UserId}");
            }
            return CreatedAtRoute(nameof(GetProperty), new { id = result.Data.PropertyId }, propertyModel);

        }
        [HttpPut, Authorize]
        public IActionResult EditProperty(PropertiesModel propertyModel)
        {
            if (propertyModel.UserId == null)
            {
                return Unauthorized();
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var propertyGetResult = _propertyRepository.Get(propertyModel.PropertyId);
            if (!propertyGetResult.Success)
            {
                return NotFound($"Property {propertyModel.PropertyId} not found");
            }

            Property property = propertyGetResult.Data;
            property.PropertyTypeId = context.PropertyType.FirstOrDefault(x => x.Description == propertyModel.Description).PropertyTypeId;
            property.TotalPrice = propertyModel.TotalPrice;
            property.RentPerMonth = propertyModel.RentPerMonth;
            property.IsRented = propertyModel.IsRented;
            property.Address = propertyModel.Address;

            var result = _propertyRepository.Update(property);
            if (!result.Success)
            {
                return BadRequest(result.Message);
            }

            if (property.IsRented)
            {
                var renterPropertyGetResult = renterPropertyRepository.GetByProperty(property.PropertyId);
                if (!renterPropertyGetResult.Success)
                {
                    return BadRequest(renterPropertyGetResult.Message);
                }
                RenterProperty renterProperty = renterPropertyGetResult.Data.FirstOrDefault(rp => rp.UserId == propertyModel.UserId);
                renterProperty.LeaseStartDate = (DateTime)propertyModel.LeaseStartDate;
                renterProperty.LeaseEndDate = (DateTime)propertyModel.LeaseEndDate;

                var renterPropertyUpdateResult = renterPropertyRepository.Update(renterProperty);
                if (!renterPropertyUpdateResult.Success)
                {
                    return BadRequest(renterPropertyUpdateResult.Message);
                }
                return Ok();
            }

            else
            {
                var buyerPropertyGetResult = buyerPropertyRepository.GetByProperty(property.PropertyId);
                if (!buyerPropertyGetResult.Success)
                {
                    return BadRequest(buyerPropertyGetResult.Message);
                }
                BuyerProperty buyerProperty = buyerPropertyGetResult.Data.FirstOrDefault(rp => rp.UserId == propertyModel.UserId);
                buyerProperty.DateOfPurchase = (DateTime)propertyModel.DateOfSale;

                var buyerPropertyUpdateResult = buyerPropertyRepository.Update(buyerProperty);
                if (!buyerPropertyUpdateResult.Success)
                {
                    return BadRequest(buyerPropertyUpdateResult.Message);
                }
                return Ok();
            }
        }
        [HttpDelete, Authorize]
        [Route("/api/[controller]/{id}")]
        public IActionResult DeleteProperty(int id)
        {
            if (!_propertyRepository.Get(id).Success)
            {
                return NotFound($"Property {id} not found");
            }

            var result = _propertyRepository.Delete(id);

            if (result.Success)
            {
                return Ok();
            }
            else
            {
                return BadRequest(result.Message);
            }
        }
    }
}

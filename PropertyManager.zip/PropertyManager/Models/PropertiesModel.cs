﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyManager.Models
{
    public class PropertiesModel : IValidatableObject
    {
        public int PropertyId { get; set; }
        public string Description { get; set; }
        public bool IsRented { get; set; }
        public decimal? TotalPrice { get; set; }
        public DateTime? DateOfSale { get; set; }
        public decimal? RentPerMonth {get; set; }
        public DateTime? LeaseStartDate { get; set; }
        public DateTime? LeaseEndDate { get; set; }
        public int? UserId { get; set; }
        public string Address { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var errors = new List<ValidationResult>();

            
            if(TotalPrice != null && TotalPrice <= 0)
            {
                errors.Add(new ValidationResult("Amount must be positive", new string[] { "Amount" }));
            }
            if (RentPerMonth != null && RentPerMonth <= 0)
            {
                errors.Add(new ValidationResult("Rent per month must be positive", new string[] { "RentPerMonth" }));
            }
            if (Description.Length > 500)
            {
                errors.Add(new ValidationResult("Description cannot be over 500 characters", new string[] { "Description" }));
            }
            return errors;

        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyManager.Models
{
    public class OfferModel
    {
        public int? OfferId { get; set; }
        public decimal Amount { get; set; }

        public int UserId { get; set; }
        public int PropertyId { get; set; }
    }
}


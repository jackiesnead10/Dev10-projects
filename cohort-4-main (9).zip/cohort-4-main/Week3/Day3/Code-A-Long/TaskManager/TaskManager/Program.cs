﻿using System;
using TaskManager.BLL;
using TaskManager.Core;
using TaskManager.DAL;

namespace TaskManager
{

    /// <summary>
    ///  Create a Task Manager, that will help us complete and track our tasks. We should see how long each task is taking us!
    /// </summary>
    public class Program
    {
        static void Main(string[] args)
        {
            ITaskRepository taskRepository = new FileTaskRepository("task.csv");
            TaskService taskService = new TaskService(taskRepository);
            TaskManagerController controller = new TaskManagerController(taskService);
            controller.Run();

        }
    }
}

﻿using NUnit.Framework;
using System;
using TaskManager.Core;

namespace TaskManager.Tests
{
    //[TestFixture]
    //public class TaskServiceTests
    //{
    //    [Test]
    //    public void CreateTask_StateUnderTest_ExpectedBehavior()
    //    {
    //        // Arrange
    //        var service = new TaskService(TODO);
    //        Task task = null;

    //        // Act
    //        var result = service.CreateTask(
    //            task);

    //        // Assert
    //        Assert.Fail();
    //    }

    //    [Test]
    //    public void ReadAllTasks_StateUnderTest_ExpectedBehavior()
    //    {
    //        // Arrange
    //        var service = new TaskService(TODO);

    //        // Act
    //        var result = service.ReadAllTasks();

    //        // Assert
    //        Assert.Fail();
    //    }

    //    [Test]
    //    public void ReadTaskById_StateUnderTest_ExpectedBehavior()
    //    {
    //        // Arrange
    //        var service = new TaskService(TODO);
    //        int id = 0;

    //        // Act
    //        var result = service.ReadTaskById(
    //            id);

    //        // Assert
    //        Assert.Fail();
    //    }
    //}
}

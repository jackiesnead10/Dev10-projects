﻿using NUnit.Framework;
using System;
using TaskManager.DAL;
using TaskManager.Core;

namespace TaskManager.Tests
{
    [TestFixture]
    public class TaskMapperTests
    {
        [Test]
        public void MapToCSV_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            Task task = new Task()
            {
                Id = 1,
                Title = "Find Diamonds",
                Completed = DateTime.Parse("1/1/0001"),
                Created = DateTime.Parse("4/14/2021")
            };
            string expected = "1,Find Diamonds,4/14/2021,1/1/0001";

            // Act
            var result = TaskMapper.MapToCSV(task);

            // Assert
            Assert.AreEqual(expected, result);
        }

        [Test]
        public void MapFromCSV_StateUnderTest_ExpectedBehavior()
        {
            Task task = new Task()
            {
                Id = 1,
                Title = "Find Diamonds",
                Completed = DateTime.Parse("1/1/0001"),
                Created = DateTime.Parse("4/14/2021")
            };
            string expected = "1,Find Diamonds,4/14/2021,1/1/0001";

            // Act
            var result = TaskMapper.MapFromCSV(expected);

            // Assert
            Assert.AreEqual(task, result);
        }
    }
}

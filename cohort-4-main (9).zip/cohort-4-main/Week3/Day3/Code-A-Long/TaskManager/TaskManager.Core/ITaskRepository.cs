﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManager.Core
{
    public interface ITaskRepository
    {
        /// <summary>
        /// Add the task to a storage, and assign an id to it
        /// </summary>
        /// <param name="task"></param>
        /// <returns></returns>
        Task CreateTask(Task task);

        List<Task> ReadAllTasks();
        Task ReadTaskById(int id);
        void UpdateTask(int id, Task task);
        void DeleteTask(int id);
    }
}

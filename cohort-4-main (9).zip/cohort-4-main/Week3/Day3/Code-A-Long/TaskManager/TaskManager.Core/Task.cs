﻿using System;

namespace TaskManager.Core
{
    public class Task
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public DateTime Created { get; set; }
        public DateTime Completed { get; set; }

        public override bool Equals(object obj)
        {
            return obj is Task task &&
                   Id == task.Id &&
                   Title == task.Title &&
                   Created == task.Created &&
                   Completed == task.Completed;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Id, Title, Created, Completed);
        }
    }
}

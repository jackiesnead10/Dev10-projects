﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TaskManager.Core;
namespace TaskManager.DAL
{
    public static class TaskMapper
    {
        public static string MapToCSV(Task task)
        {
            return $"{task.Id},{task.Title},{task.Created.ToShortDateString()},{task.Completed.ToShortDateString()}";
        }
        public static Task MapFromCSV(string line)
        {
            string[] fields = line.Split(',');
            Task task = new Task();
            task.Id = int.Parse(fields[0]);
            task.Title = fields[1];
            task.Created = DateTime.Parse(fields[2]);
            task.Completed = DateTime.Parse(fields[3]);
            return task;
        }
    }
}

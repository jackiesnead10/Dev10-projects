﻿using System;
using System.Collections.Generic;
using TaskManager.Core;
namespace TaskManager.DAL
{
   

    /// <summary>
    /// Manage Task Storage using CRUD methods
    /// </summary>
    public class TaskRepository : ITaskRepository
    {
        private List<Task> _tasks;
        //CRUD

        public TaskRepository()
        {
            _tasks = new List<Task>();
        }

        /// <summary>
        /// Add the task to a storage, and assign an id to it
        /// </summary>
        /// <param name="task"></param>
        /// <returns></returns>
        public Task CreateTask(Task task)
        {
            int nextId = 0;
            foreach (var currentTask in _tasks)
            {
                if (nextId < currentTask.Id)
                {
                    nextId = currentTask.Id;
                }
            }

            nextId++;
            task.Id = nextId;
            _tasks.Add(task);

            return null;
        }

        public List<Task> ReadAllTasks()
        {
            return _tasks;
        }

        public Task ReadTaskById(int id)
        {
            foreach (var task in _tasks)
            {
                if (id == task.Id)
                {
                    return task;
                }
            }
            return null;
        }

        public void UpdateTask(int id, Task task)
        {
            for (var i = 0; i < _tasks.Count; i++)
            {
                var currentTask = _tasks[i];
                if (id == currentTask.Id)
                {
                    _tasks[i] = task;
                    break;
                }
            }

        }

        public void DeleteTask(int id)
        {
            int index = -1;
            for (var i = 0; i < _tasks.Count; i++)
            {
                var currentTask = _tasks[i];
                if (id == currentTask.Id)
                {
                    index = i;
                    break;
                }
            }

            if (index >= 0)
            {
                _tasks.RemoveAt(index);
            }
        }

    }
}

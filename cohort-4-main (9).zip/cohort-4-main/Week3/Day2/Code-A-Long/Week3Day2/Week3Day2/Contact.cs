﻿using System;

namespace Week3Day2
{
    public class Contact
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public int Age { get; set; }
        public decimal Weight { get; set; }

        public ConsoleColor HairColor { get; set; }

        public override bool Equals(object obj)
        {
            return obj is Contact contact &&
                   FirstName == contact.FirstName &&
                   LastName == contact.LastName &&
                   Age == contact.Age &&
                   Weight == contact.Weight &&
                   HairColor == contact.HairColor;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(FirstName, LastName, Age, Weight, HairColor);
        }

        public virtual string CallFriend()
        {
            return "Hello friend!";
        }

        //public override int GetHashCode()
        //{
        //    return HashCode.Combine(FirstName, LastName, Age, Weight, HairColor);
        //}
    }
}

﻿using System;
using System.Collections.Generic;

namespace Week3Day2
{
    class Program
    {
        static void Main(string[] args)
        {
            Contact contact = new Contact() { FirstName = "Randall", LastName = "Clapper", Age = 51 };
            BusinessContact contact2 = new BusinessContact() {Title="Great Wizard", FirstName = "Randall", LastName = "Clapper", Age = 51 };


            Console.WriteLine(contact.CallFriend());
            Console.WriteLine(contact2.CallFriend());




            List<Contact> testList = new List<Contact>();
            testList.Add(contact2);
            testList.Contains(contact2);
    

            Console.WriteLine(".Equals(contact, contact2) : " + contact.Equals(contact2));
             Console.WriteLine("contact == contact2 : " + (contact == contact2));

            Dictionary<Contact, List<Contact>> friendList = new Dictionary<Contact, List<Contact>>();
            friendList.Add(contact2, new List<Contact>());
            friendList.Add(contact, new List<Contact>());
            contact.Age = 651;
            Console.WriteLine("Has contact:" + friendList.ContainsKey(contact));
            Console.WriteLine("Contact 1 HashCode: " + contact.GetHashCode());
            Console.WriteLine("Contact 2 HashCode: " + contact2.GetHashCode());
        }
    }
}

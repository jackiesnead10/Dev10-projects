﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week3Day2
{
    public class BusinessContact : Contact
    {
        public string Title { get; set; }

        public override string CallFriend()
        {
            return $"Hello {Title} {LastName}";
        }
    }
}

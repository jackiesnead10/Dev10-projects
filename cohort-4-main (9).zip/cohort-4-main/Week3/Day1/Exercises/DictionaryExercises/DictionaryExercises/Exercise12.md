# Exercise13

1. Add a class, `Student`, to the project.
2. Add properties:
    - `int StudentId`
    - `string FirstName`
    - `string LastName`
3. Inside `Program.cs`, instantiate a `Dictionary<int, Student>`.
4. Add at least three students to the map using their StudentId as the key.
5. Retrieve one student and display them.
6. Delete one student.
7. Display all students.
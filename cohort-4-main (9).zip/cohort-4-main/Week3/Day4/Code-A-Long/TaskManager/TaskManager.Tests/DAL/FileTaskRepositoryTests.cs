﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using TaskManager.DAL;
using TaskManager.Core;
namespace TaskManager.Tests.DAL
{
    [TestFixture]
    public class FileTaskRepositoryTests
    {
        private ILogger _logger = new NullLogger();
        [Test]
        public void ShouldCreateABlankFileWhenGivenAFilePathNotPresent()
        {
            string fileName = DateTime.Now.ToString("MMddyyyy.csv");
            FileTaskRepository taskRepository = new FileTaskRepository(fileName, _logger);

            Assert.IsTrue(File.Exists(fileName));
            File.Delete(fileName);
        }

        [Test]
        public void ShouldReadFileWhenGivenAExistingFile()
        {
            // Arranging
            string fileName = "testSeed.csv";
            int expectedCount = 1;
            Task task = new Task();
            task.Id = 1;
            task.Category = "Gaming";
            task.Title = "Diamonds!!";
            task.Created = DateTime.Parse("4/1/2021");
            task.Completed = DateTime.Parse("4/14/2021");
            // Act
            FileTaskRepository taskRepository = new FileTaskRepository(fileName, _logger);
            List<Task> tasks = taskRepository.ReadAllTasks();
            // Asserting
            Assert.AreEqual(expectedCount, tasks.Count);
            Assert.AreEqual(task, tasks[0]);
        }
        [Test]
        public void ShouldAddANewTaskToList()
        {
            // Arranging
            string fileName = "AddNewTask.csv";
            int exepctedCount = 1;
            Task task = new Task
            {
                Title = "Diamonds!!",
                Created = DateTime.Parse("4/1/2021"),
                Completed = DateTime.Parse("4/14/2021"),
                Category = "Gaming"
            };

            // ACT
            FileTaskRepository taskRepository = new FileTaskRepository(fileName, _logger);

            Task newTask = taskRepository.CreateTask(task);
            List<Task> tasks = taskRepository.ReadAllTasks();
            // Asserting
            Assert.AreEqual(exepctedCount, tasks.Count);
            Assert.AreEqual(1, newTask.Id);
            Assert.AreEqual(newTask, tasks[0]);
            File.Delete(fileName);

        }
        [Test]
        public void ShouldSaveNewTaskToFile()
        {
            // Arranging
            string fileName = DateTime.Now.ToString("MMddyyyy.csv");
            int exepctedCount = 1;
            Task task = new Task
            {
                Title = "Diamonds!!",
                Created = DateTime.Parse("4/1/2021"),
                Completed = DateTime.Parse("4/14/2021"),
                Category = "Gaming"
            };

            // ACT
            FileTaskRepository taskRepository = new FileTaskRepository(fileName, _logger);

            Task newTask = taskRepository.CreateTask(task);

            FileTaskRepository taskRepository2 = new FileTaskRepository(fileName, _logger);
            List<Task> tasks = taskRepository2.ReadAllTasks();
            // Asserting
            Assert.AreEqual(exepctedCount, tasks.Count);
            Assert.AreEqual(1, newTask.Id);
            Assert.AreEqual(newTask, tasks[0]);
            File.Delete(fileName);
        }
        [Test]
        public void ShouldRetreiveAExistingTaskById()
        {
            string fileName = DateTime.Now.ToString("MMddyyyy.csv");
            Task task = new Task
            {
                Title = "Diamonds!!",
                Created = DateTime.Parse("4/1/2021"),
                Completed = DateTime.Parse("4/14/2021"),
                Category = "Gaming"
            };

            // ACT
            FileTaskRepository taskRepository = new FileTaskRepository(fileName, _logger);

            Task newTask = taskRepository.CreateTask(task);

            Task foundTask = taskRepository.ReadTaskById(1);

            // Asserting

            Assert.AreEqual(newTask, foundTask);
            File.Delete(fileName);
        }
        [Test]
        public void ShouldReturnNullWhenIdIsNotFound()
        {
            string fileName = DateTime.Now.ToString("MMddyyyy.csv");

            // ACT
            FileTaskRepository taskRepository = new FileTaskRepository(fileName, _logger);



            Task foundTask = taskRepository.ReadTaskById(1);

            // Asserting

            Assert.IsNull(foundTask);
            File.Delete(fileName);
        }
        [Test]
        public void ShouldUpdateTaskSaveToFile()
        {
            string fileName = "UpdatedTask.csv";
            File.Delete(fileName);
            Task task = new Task
            {
                Title = "Diamonds!!",
                Created = DateTime.Parse("4/1/2021"),
                Completed = DateTime.Parse("4/1/2021"),
                Category = "Gaming"
            };

            Task updated = new Task
            {
                Id = 1,
                Title = "Diamonds!!",
                Created = DateTime.Parse("4/1/2021"),
                Completed = DateTime.Parse("4/14/2021"),
                Category = "Gaming"
            };
            // ACT
            FileTaskRepository taskRepository = new FileTaskRepository(fileName, _logger);

            taskRepository.CreateTask(task);

            Task foundTask = taskRepository.ReadTaskById(1);
            foundTask.Completed = DateTime.Parse("4/14/2021");
            taskRepository.UpdateTask(1, foundTask);
            FileTaskRepository taskRepository2 = new FileTaskRepository(fileName, _logger);
            Task foundTask2 = taskRepository2.ReadTaskById(1);

            // Asserting

            Assert.AreEqual(updated, foundTask2);
        }

        [Test]
        public void ShouldDeleteAndSave()
        {
            string fileName = "UpdatedTask.csv";
            File.Delete(fileName);
            Task task = new Task
            {
                Title = "Diamonds!!",
                Created = DateTime.Parse("4/1/2021"),
                Completed = DateTime.Parse("4/1/2021"),
                Category = "Gaming"
            };


            FileTaskRepository taskRepository = new FileTaskRepository(fileName, _logger);

            taskRepository.CreateTask(task);

            taskRepository.DeleteTask(1);
            FileTaskRepository taskRepository2 = new FileTaskRepository(fileName, _logger);
            Task foundTask2 = taskRepository2.ReadTaskById(1);

            // Asserting

            Assert.IsNull(foundTask2);
        }
    }
}

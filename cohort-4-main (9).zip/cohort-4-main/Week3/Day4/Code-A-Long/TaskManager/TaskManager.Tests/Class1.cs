﻿using System;

namespace TaskManager.Tests
{
    public class Class1
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TaskManager.Core;
using Task = TaskManager.Core.Task;

namespace TaskManager.DAL
{
    public class FileTaskRepository : ITaskRepository
    {
        private string _fileName;
        private List<Task> _tasks;
        private ILogger _logger;
        public FileTaskRepository(string fileName, ILogger logger)
        {
            _fileName = fileName;
            _tasks = new List<Task>();
            _logger = logger;
            LoadTasks();
        }

        private void LoadTasks()
        {
            try
            {
                if (!File.Exists(_fileName))
                {
                    File.Create(_fileName).Close();
                }
                else
                {
                    using (StreamReader sr = new StreamReader(_fileName))
                    {
                        // ID, TItle, Created, Completed
                        // 1,Find Diamonds,1/1/2021,4/14/2021
                        // fields[0] = "1"
                        // fields[1] = "Find Diamonds"
                        // fields[2] = "1/1/2021"
                        // fields[3] = "1/1/2021"
                        for (string line = sr.ReadLine(); line != null; line = sr.ReadLine())
                        {
                            string[] fields = line.Split(',');
                            Task task = new Task();
                            task.Id = int.Parse(fields[0]);
                            task.Title = fields[1];
                            task.Created = DateTime.Parse(fields[2]);
                            task.Completed = DateTime.Parse(fields[3]);
                            task.Category = fields[4];
                            _tasks.Add(task);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Log(ex.Message);
                //throw new DALException($"Error Loading file {_fileName}", ex);
            }
        }
        private void SaveTasks()
        {
            try
            {


                using (StreamWriter sw = new StreamWriter(_fileName))
                {

                    foreach (var task in _tasks)
                    {
                        sw.WriteLine($"{task.Id},{task.Title},{task.Created.ToShortDateString()},{task.Completed.ToShortDateString()},{task.Category}");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Log(ex.Message);
                throw new DALException($"Unable to save to file {_fileName}", ex);
            }

        }
        public Task CreateTask(Task task)
        {
            int nextId = 0;
            foreach (var currentTask in _tasks)
            {
                if (nextId < currentTask.Id)
                {
                    nextId = currentTask.Id;
                }
            }

            nextId++;
            task.Id = nextId;
            _tasks.Add(task);
            SaveTasks();
            return task;
        }



        public List<Task> ReadAllTasks()
        {
            return _tasks;
        }

        public Task ReadTaskById(int id)
        {
            foreach (var task in _tasks)
            {
                if (id == task.Id)
                {
                    return task;
                }
            }
            return null;
        }

        public void UpdateTask(int id, Task task)
        {
            for (var i = 0; i < _tasks.Count; i++)
            {
                var currentTask = _tasks[i];
                if (id == currentTask.Id)
                {
                    _tasks[i] = task;
                    SaveTasks();
                    break;
                }
            }

        }

        public void DeleteTask(int id)
        {
            int index = -1;
            for (var i = 0; i < _tasks.Count; i++)
            {
                var currentTask = _tasks[i];
                if (id == currentTask.Id)
                {
                    index = i;
                    break;
                }
            }

            if (index >= 0)
            {
                _tasks.RemoveAt(index);
                SaveTasks();
            }
        }
    }
}

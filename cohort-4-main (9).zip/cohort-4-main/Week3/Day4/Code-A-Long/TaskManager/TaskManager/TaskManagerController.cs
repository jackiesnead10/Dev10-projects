﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TaskManager.BLL;
using TaskManager.Core;

namespace TaskManager
{
    public class TaskManagerController
    {
        private TaskService _taskService;

        public TaskManagerController(TaskService taskService)
        {
            _taskService = taskService;
        }
        public void Run()
        {
            // Keep the application running, display a menu for CRUD of tasks
            do
            {


                int choice = ConsoleIO.PromptInt("0. Exit\n1. Create Task\n2. Read All\n3. Find Task\n4.Search Category", 0, 4);
                switch (choice)
                {
                    case 0:
                        ConsoleIO.Display("Good bye");
                        return;
                    case 1:
                        CreateTask();
                        break;
                    case 2:
                        DisplayTasks();
                        break;
                    case 3:
                        FindTask();
                        break;
                    case 4:
                        SearchCategory();
                        break;
                }
            } while (true);
        }

        private void SearchCategory()
        {
           string searchCategory = ConsoleIO.PromptUser("Enter a category");
           Dictionary<string, List<Task>> taskByCategory = _taskService.GetTasksByCategory(searchCategory);
           ConsoleIO.DisplayTasksByCategory(taskByCategory);
        }

        private void FindTask()
        {
            int taskId = ConsoleIO.PromptInt("Enter Task Id:");
            Result result = _taskService.ReadTaskById(taskId);
            if (result.Success)
            {
                ConsoleIO.DisplayTask(result.Data);
            }
            else
            {
                ConsoleIO.DisplayError(result.Message);
            }
        }

        private void DisplayTasks()
        {

            List<Task> tasks = _taskService.ReadAllTasks();
            ConsoleIO.DisplayTasks(tasks);

        }

        private void CreateTask()
        {
            Task task = ConsoleIO.PromptUserTask("Create New Task");
            Result result = _taskService.CreateTask(task);
            if (result.Success)
            {
                ConsoleIO.Display(result.Message);
            }
            else
            {
                ConsoleIO.DisplayError(result.Message);
            }
        }
    }
}

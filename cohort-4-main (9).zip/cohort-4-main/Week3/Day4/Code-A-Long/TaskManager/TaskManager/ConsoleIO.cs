﻿using System;
using System.Collections.Generic;
using System.Globalization;
using TaskManager.Core;
namespace TaskManager
{
    public static class ConsoleIO
    {
        public static void Display(string prompt)
        {
            Console.WriteLine(prompt);
        }

        public static string PromptUser(string prompt)
        {
            string output;
            do
            {
                Console.WriteLine(prompt);
                output = Console.ReadLine();
            } while (string.IsNullOrEmpty(output.Trim()));
            return output;
        }

        public static Task PromptUserTask(string prompt)
        {
            Task task = new Task();
            task.Title = PromptUser("Please enter a title:");
            task.Created = DateTime.Now;
            task.Completed = PromptUserDate("Please Enter Completed Date");
            task.Category = PromptUser("Please enter a category");
            return task;
        }

        public static int PromptInt(string prompt)
        {
            int output;
            bool valid;
            do
            {
                valid = int.TryParse(PromptUser(prompt), out output);
            } while (!valid);
            return output;
        }

        public static int PromptInt(string prompt, int min, int max)
        {
            int output;
            do
            {
                output = PromptInt(prompt);
            } while (output < min || output > max);
            return output;
        }

        public static DateTime PromptUserDate(string prompt)
        {
            DateTime output;
            do
            {
            } while (!DateTime.TryParseExact(PromptUser(prompt), "MM/dd/yy", CultureInfo.InvariantCulture, DateTimeStyles.None, out output));
            return output;
        }

        internal static void DisplayTasksByCategory(Dictionary<string, List<Task>> taskByCategory)
        {
            foreach (string category in taskByCategory.Keys)
            {
                Display(category);
                foreach (Task task in taskByCategory[category])
                {
                    Display($"\t{task.Id} {task.Title} {task.Created.ToShortDateString()} - {task.Completed.ToShortDateString()}");
                }
            }
        }

        public static void DisplayTask(Task task)
        {
           Display($"{task.Id} {task.Title} {task.Created.ToShortDateString()} - {task.Completed.ToShortDateString()}");
        }

        public static void DisplayError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
            Console.ResetColor();
        }

        public static DateTime PromptUserDate(string prompt, DateTime max)
        {
            DateTime output;
            do
            {
                output = PromptUserDate(prompt);
            } while (output >= max);
            return output;
        }

        public static void PrintDate(string message, DateTime date)
        {
            Console.WriteLine($"{message}{date.ToString()}");
        }

        public static void PrintDateDifference(string message, TimeSpan difference)
        {
            Console.WriteLine($"{difference.Hours}{message}");
        }

        public static void DisplayTasks(List<Task> tasks)
        {
            foreach (var task in tasks)
            {
                Display($"{task.Id} {task.Title} {task.Completed.ToShortDateString()}");
            }
        }
    }
}

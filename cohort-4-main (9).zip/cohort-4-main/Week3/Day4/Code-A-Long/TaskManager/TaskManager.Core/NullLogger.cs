﻿namespace TaskManager.Core
{
    public class NullLogger : ILogger
    {
        public void Log(string message)
        {
            
        }
    }
}

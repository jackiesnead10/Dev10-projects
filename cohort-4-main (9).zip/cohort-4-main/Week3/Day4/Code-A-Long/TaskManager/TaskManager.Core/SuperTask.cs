﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManager.Core
{
    public class TaskReport
    {
        public string TaskCategory { get; set; }
        public int Count { get; set; }
        public int AverageMinute { get; set; }
    }
}

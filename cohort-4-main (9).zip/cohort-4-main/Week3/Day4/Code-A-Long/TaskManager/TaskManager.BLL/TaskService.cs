﻿using System;
using System.Linq;
using System.Collections.Generic;
using TaskManager.Core;
using TaskManager.DAL;
namespace TaskManager.BLL
{
    public class TaskService
    {
        private ITaskRepository _taskRepository;

        public TaskService(ITaskRepository taskRepository)
        {
            _taskRepository = taskRepository;
        }

        public Result CreateTask(Task task)
        {
            //TODO: Put in validation for Tasks
            Result result = new Result();

            if (string.IsNullOrEmpty(task.Title))
            {
                result.Message = "Task Title is required";
                result.Success = false;
                return result;
            }


            try
            {
                _taskRepository.CreateTask(task);
                result.Success = true;
                result.Message = "Created Task Successfully";
            }
            catch (DALException ex)
            {
                result.Success = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public List<Task> ReadAllTasks()
        {
            return _taskRepository.ReadAllTasks();
        }

        public Result ReadTaskById(int id)
        {
            Task task = _taskRepository.ReadTaskById(id);
            Result result = new Result();
            if (task == null)
            {
                result.Success = false;
                result.Message = $"Task Id: {id} was not found";
            }
            else
            {
                result.Success = true;
                result.Data = task;
            }
            return result;
        }

        public Dictionary<string, List<Task>> GetTasksByCategory(string searchTerm)
        {
            List<Task> tasks = _taskRepository.ReadAllTasks();
            // how to do grouping using a for loop

            //Dictionary<string, List<Task>> groupTasks = new Dictionary<string, List<Task>>();

            //foreach (var task in tasks)
            //{
            //    if (groupTasks.ContainsKey(task.Category))
            //    {
            //        groupTasks[task.Category].Add(task);

            //    }
            //    else
            //    {
            //        groupTasks.Add(task.Category, new List<Task>() { task});
            //    }
            //}

            // Games
            // Board Games
            int search = 2;

            IEnumerable<Task> query = _taskRepository.ReadAllTasks().Where(t => true);
            if(search > 0){
                query = query.Where((task, i) => task.Title == searchTerm);

            }
            if(search == 2)
            {
                query = query.Where(task => task.Category == searchTerm);

            }


            Dictionary<string, List<Task>> query = (from task in tasks
                        where task.Category.Contains(searchTerm)
                        group task by task.Category into g
                        select g).ToDictionary(g => g.Key, g=> g.ToList());
            return query;
        }

        public List<string> GetTaskSummary()
        {
            List<string> taskSummary = new List<string>();

            foreach (var task in _taskRepository.ReadAllTasks())
            {
                taskSummary.Add($"{task.Category}-{task.Title}");
            }

            IEnumerable<string> query = from task in _taskRepository.ReadAllTasks()
            
                                        select $"{task.Category}-{task.Title}";
            return query.ToList();
        }
    }
}

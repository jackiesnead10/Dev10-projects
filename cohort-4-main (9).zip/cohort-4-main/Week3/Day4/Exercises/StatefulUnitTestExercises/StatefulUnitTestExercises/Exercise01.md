# Exercise01

1. Open `Submarine` from StatefulUnitTestExercises and `SubmarineTest` from StatefulUnitTestExercises.Tests.
2. To understand `Submarine`, read its docs.
3. Implement the numbered changes in each class. For each change, drive your development by writing tests.
    Your process should be:
    - Write some code. Confirm it's correct with a test.
    - Write some code. Confirm it's correct with a test.
    - Repeat until complete.
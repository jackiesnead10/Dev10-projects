# Exercise03

1. Create a new class `Knight` in the `Chess` namespace.
2. Model its location with integer `Row` and `Column` properties.
3. Add a `Move` method. (See Exercise02.)
4. Generate tests for `Knight`.
5. Complete the `Move` method and confirm it's correct with tests.
    See https://en.wikipedia.org/wiki/Knight_(chess) for the Knight's movement rules.
# Exercise04

1. Open both `LineItem` and `Order` in the `Commerce` namespace.
2. Read their docs to understand what they are and how they operate.
3. Open `Commerce.OrderTest` and check the existing tests.
4. Implement the requested changes in both `Order` and `OrderTest`. Use your tests to guide development.
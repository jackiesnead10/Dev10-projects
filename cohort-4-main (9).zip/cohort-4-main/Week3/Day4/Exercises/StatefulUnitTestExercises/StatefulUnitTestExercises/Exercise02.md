# Exercise02

1. Open `Chess.Queen` and `Chess.QueenTest`.
2. To understand `Queen`, read its docs.
3. Implement the numbered changes in each class. 
    For each change, drive your development by writing tests.
﻿using System;
using System.Collections.Generic;
using UnexplainedEncounters.Core;

namespace UnexplainedEncounters.DAL
{
    public class MemoryEncounterRepository : IEncounterRepository
    {
        private List<Encounter> encounters = new List<Encounter>();

        public Encounter Add(Encounter encounter)
        {
            int nextId = 0;
            foreach(Encounter e in encounters)
            {
                nextId = Math.Max(e.EncounterId, nextId);
            }
            encounter.EncounterId = nextId + 1;
            encounters.Add(encounter);
            return encounter;
        }

        public bool DeleteById(int encounterId)
        {
            for(int i = 0; i < encounters.Count; i++)
            {
                if(encounters[i].EncounterId == encounterId)
                {
                    encounters.RemoveAt(i);
                    return true;
                }
            }
            return false;
        }

        public List<Encounter> FindAll()
        {
            // always copy the list,
            // never return a references to a real data source!
            return new List<Encounter>(encounters);
        }

        public List<Encounter> FindByDate(DateTime date)
        {
            List<Encounter> result = new List<Encounter>();
            foreach(Encounter e in encounters)
            {
                if(e.When.Date.Equals(date.Date))
                {
                    result.Add(e);
                }
            }
            return result;
        }

        public Encounter FindById(int encounterId)
        {
            foreach(Encounter e in encounters)
            {
                if(e.EncounterId == encounterId)
                {
                    return e;
                }
            }
            return null;
        }

        public List<Encounter> FindByType(EncounterType type)
        {
            List<Encounter> result = new List<Encounter>();
            foreach(Encounter e in encounters)
            {
                if(e.EncounterType == type)
                {
                    result.Add(e);
                }
            }
            return result;
        }

        public bool Update(Encounter encounter)
        {
            for(int i = 0; i < encounters.Count; i++)
            {
                if(encounters[i].EncounterId == encounter.EncounterId)
                {
                    encounters[i] = encounter;
                    return true;
                }
            }
            return false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using UnexplainedEncounters.Core;

namespace UnexplainedEncounters.DAL
{
    public class FileEncounterRepository : IEncounterRepository
    {
        private const string COMMA_ESCAPE = "~^~";
        private readonly string filePath;

        public FileEncounterRepository(string filePath)
        {
            this.filePath = filePath;
        }

        public Encounter Add(Encounter encounter)
        {
            List<Encounter> encounters = FindAll();
            int nextId = 0;
            foreach(Encounter e in encounters)
            {
                nextId = Math.Max(e.EncounterId, nextId);
            }
            encounter.EncounterId = nextId + 1;
            encounters.Add(encounter);
            Write(encounters);
            return encounter;
        }


        public List<Encounter> FindAll()
        {
            List<Encounter> encounters = new List<Encounter>();
            if(File.Exists(filePath))
            {
                string[] lines = File.ReadAllLines(filePath);
                foreach(string line in lines)
                {
                    encounters.Add(FromLine(line));
                }
            }
            return encounters;
        }

        public List<Encounter> FindByDate(DateTime date)
        {
            List<Encounter> result = new List<Encounter>();
            foreach(Encounter e in FindAll())
            {
                if(e.When.Date.Equals(date.Date))
                {
                    result.Add(e);
                }
            }
            return result;
        }

        public Encounter FindById(int encounterId)
        {
            foreach(Encounter e in FindAll())
            {
                if(e.EncounterId == encounterId)
                {
                    return e;
                }
            }
            return null;
        }

        public List<Encounter> FindByType(EncounterType type)
        {
            List<Encounter> result = new List<Encounter>();
            foreach(Encounter e in FindAll())
            {
                if(e.EncounterType == type)
                {
                    result.Add(e);
                }
            }
            return result;
        }

        public bool Update(Encounter encounter)
        {
            List<Encounter> encounters = FindAll();
            for(int i = 0; i < encounters.Count; i++)
            {
                if(encounters[i].EncounterId == encounter.EncounterId)
                {
                    encounters[i] = encounter;
                    Write(encounters);
                    return true;
                }
            }

            return false;
        }

        public bool DeleteById(int encounterId)
        {
            List<Encounter> encounters = FindAll();
            for(int i = 0; i < encounters.Count; i++)
            {
                if(encounters[i].EncounterId == encounterId)
                {
                    encounters.RemoveAt(i);
                    Write(encounters);
                    return true;
                }
            }

            return false;
        }

        private void Write(List<Encounter> encounters)
        {
            using(StreamWriter writer = new StreamWriter(filePath))
            {
                foreach(Encounter encounter in encounters)
                {
                    writer.WriteLine(ToLine(encounter));
                }
            }
        }

        private Encounter FromLine(string line)
        {
            string[] fields = line.Split(',');
            Encounter encounter = new Encounter();
            encounter.EncounterId = int.Parse(fields[0]);
            encounter.When = DateTime.Parse(fields[1]);
            encounter.EncounterType = Enum.Parse<EncounterType>(fields[2]);
            encounter.Description = fields[3].Replace(COMMA_ESCAPE, ","); // put commas back
            encounter.HasWitness = fields[4] == "true";
            return encounter;
        }

        private string ToLine(Encounter encounter)
        {
            string[] fields =
            {
                encounter.EncounterId.ToString(),
                encounter.When.ToString("g"),
                encounter.EncounterType.ToString(),
                encounter.Description.Replace(",", COMMA_ESCAPE), // don't include commas, though still dangerous...
                encounter.HasWitness ? "true" : "false"
            };
            return string.Join(',', fields);
        }
    }
}

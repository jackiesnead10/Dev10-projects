﻿using System;
using System.Collections.Generic;
using UnexplainedEncounters.Core;

namespace UnexplainedEncounters.BLL
{
    public class EncounterService
    {
        private readonly IEncounterRepository repository;

        public EncounterService(IEncounterRepository repository)
        {
            this.repository = repository;
        }

        public List<Encounter> FindAll()
        {
            return repository.FindAll();
        }

        public List<Encounter> FindByDate(DateTime date)
        {
            return repository.FindByDate(date);
        }

        public List<Encounter> FindByType(EncounterType type)
        {
            return repository.FindByType(type);
        }

        public Result<Encounter> Add(Encounter encounter)
        {
            Result<Encounter> result = Validate(encounter);
            if(!result.IsSuccess)
            {
                return result;
            }

            result.Value = repository.Add(encounter);

            return result;
        }

        public Result<Encounter> Update(Encounter encounter)
        {
            Result<Encounter> result = Validate(encounter);
            if(!result.IsSuccess)
            {
                return result;
            }

            if(!repository.Update(encounter))
            {
                result.AddMessage("encounter was not updated.");
            }

            return result;
        }

        public bool DeleteById(int encounterid)
        {
            return repository.DeleteById(encounterid);
        }

        private Result<Encounter> Validate(Encounter encounter)
        {
            Result<Encounter> result = new Result<Encounter>();
            if(encounter == null)
            {
                result.AddMessage("encounter cannot be null.");
                return result;
            }

            if(string.IsNullOrWhiteSpace(encounter.Description))
            {
                result.AddMessage("Description is required.");
            }

            if(encounter.When > DateTime.Now)
            {
                result.AddMessage("When cannot be in the future.");
            }

            if(encounter.When < DateTime.Now.AddYears(-100))
            {
                result.AddMessage("When is too far in the past.");
            }

            if(!result.IsSuccess)
            {
                return result;
            }

            if(IsDuplicate(encounter))
            {
                result.AddMessage("Encounter is a duplicate.");
            }

            return result;
        }

        private bool IsDuplicate(Encounter encounter)
        {
            List<Encounter> encounters = repository.FindByDate(encounter.When);
            foreach(Encounter e in encounters)
            {
                if(e.EncounterId != encounter.EncounterId // different id
                    && e.Description == encounter.Description // same description
                    && e.EncounterType == encounter.EncounterType // same type
                    && Math.Abs(e.When.Subtract(encounter.When).TotalMinutes) < 30) // very close together
                {
                    return true;
                }
            }
            return false;
        }
    }
}

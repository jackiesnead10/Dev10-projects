﻿using System;

namespace UnexplainedEncounters.CLI
{
    public static class ConsoleIO
    {
        public static string ReadString(string prompt, string currentValue = null)
        {
            Console.Write(prompt);
            string input = Console.ReadLine().Trim();
            if(input.Length == 0 && currentValue != null)
            {
                return currentValue;
            }
            return input;
        }

        public static int ReadInt(string prompt)
        {
            int result;
            bool success;
            do
            {
                string input = ReadString(prompt);
                success = int.TryParse(input, out result);
                if(!success)
                {
                    PrintFailure("[ERR]: enter a valid whole number.");
                }
            } while(!success);

            return result;
        }

        public static int ReadInt(string prompt, int min, int max)
        {
            int result;
            do
            {
                result = ReadInt(prompt);
                if(result < min || result > max)
                {
                    PrintFailure($"[ERR]: value must be between {min} and {max}.");
                }
            } while(result < min || result > max);

            return result;
        }

        public static DateTime ReadDateTime(string prompt, DateTime? currentValue = null)
        {
            DateTime result;
            bool success;
            do
            {
                string input = ReadString(prompt).Trim();
                if(input.Length == 0 && currentValue.HasValue)
                {
                    return currentValue.Value;
                }

                success = DateTime.TryParse(input, out result);
                if(!success)
                {
                    PrintFailure("[ERR]: enter a date and optional time in MM/dd/yyyy [HH:mm PM] format.");
                }
            } while(!success);

            return result;
        }


        public static void PrintSuccess(string message)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(message);
            Console.ResetColor();
        }

        public static void PrintFailure(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
            Console.ResetColor();
        }
    }
}

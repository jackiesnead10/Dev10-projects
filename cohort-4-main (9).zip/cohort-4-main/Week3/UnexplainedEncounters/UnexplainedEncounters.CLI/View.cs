﻿using System;
using System.Collections.Generic;
using UnexplainedEncounters.BLL;
using UnexplainedEncounters.Core;
using static UnexplainedEncounters.CLI.ConsoleIO;

namespace UnexplainedEncounters.CLI
{
    public class View
    {
        public MainMenuOption ChooseFromMenu()
        {
            PrintHeader("Main Menu");

            MainMenuOption[] values = Enum.GetValues<MainMenuOption>();
            for(int i = 0; i < values.Length; i++)
            {
                Console.WriteLine($"{i}. {values[i].ToLabel()}");
            }
            int index = ReadInt($"Select [0-{values.Length - 1}]: ", 0, values.Length - 1);
            return values[index];
        }

        public void PrintHeader(string message)
        {
            Console.WriteLine();
            Console.WriteLine(message);
            Console.WriteLine(new string('=', message.Length));
        }

        public void ShowAllEncounters(List<Encounter> encounters)
        {
            PrintHeader(MainMenuOption.ShowAllEncounters.ToLabel());
            PrintEncounters(encounters);
            Console.WriteLine();
        }

        public Encounter MakeEncounter()
        {
            PrintHeader(MainMenuOption.AddAnEncounter.ToLabel());
            Encounter encounter = new Encounter();
            encounter.When = ReadDateTime("When [MM/dd/yyyy [HH:mm PM]]: ");
            encounter.EncounterType = ReadEncounterType();
            encounter.Description = ReadString("Description: ");
            encounter.HasWitness = ReadString("Witness [y/n]: ")
                .Equals("y", StringComparison.OrdinalIgnoreCase);
            return encounter;
        }

        public Encounter UpdateEncounter(Encounter encounter)
        {
            Console.WriteLine("Press [Enter] to keep the current value.");
            encounter.When = ReadDateTime($"When ({encounter.When:g}) [MM/dd/yyyy [HH:mm PM]]: ", encounter.When);
            encounter.EncounterType = ReadEncounterType();
            encounter.Description = ReadString($"Description ({encounter.Description}): ", encounter.Description);
            string witness = encounter.HasWitness ? "y" : "n";
            encounter.HasWitness = ReadString($"Witness ({witness}) [y/n]: ", witness)
                .Equals("y", StringComparison.OrdinalIgnoreCase);

            return encounter;
        }

        public void PrintResult(Result<Encounter> result)
        {
            if(result.IsSuccess)
            {
                PrintSuccess("Success");
            }
            else
            {
                foreach(string message in result.Messages)
                {
                    PrintFailure($"[ERR] {message}");
                }
            }
            Console.WriteLine();
        }

        public void PrintStatus(bool success, string failureMessage)
        {
            if(success)
            {
                PrintSuccess("Success");
            }
            else
            {
                PrintFailure(failureMessage);
            }
        }

        public Encounter ChooseEncounter(List<Encounter> encounters)
        {
            PrintEncounters(encounters);
            if(encounters == null || encounters.Count == 0)
            {
                return null;
            }

            int encounterId = ReadInt("Choose an encounter by ID: ");
            Encounter encounter = null;
            foreach(Encounter e in encounters)
            {
                if(e.EncounterId == encounterId)
                {
                    encounter = e;
                    break;
                }
            }

            if(encounter == null)
            {
                PrintFailure($"[ERR] No encounter with ID: {encounterId}.");
            }

            return encounter;
        }

        public DateTime GetDate(MainMenuOption option)
        {
            PrintHeader(option.ToLabel());
            return ReadDateTime("Date [MM/dd/yyyy]: ");
        }

        public EncounterType GetEncounterType(MainMenuOption option)
        {
            PrintHeader(option.ToLabel());
            return ReadEncounterType();
        }

        public void PrintEncounters(List<Encounter> encounters, string failureMessage = "No encounters found.")
        {
            if(encounters == null || encounters.Count == 0)
            {
                PrintFailure(failureMessage);
                return;
            }

            foreach(Encounter e in encounters)
            {
                Console.WriteLine($"{e.EncounterId}. {e.When}, {e.EncounterType}, {e.Description}, {(e.HasWitness ? "witnesses" : "no witnesses")}");
            }
        }


        private EncounterType ReadEncounterType()
        {
            Console.WriteLine("Encounter Type");
            EncounterType[] values = Enum.GetValues<EncounterType>();
            for(int i = 0; i < values.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {values[i]}");
            }
            int choice = ReadInt($"Select [1-{values.Length}]: ", 1, values.Length);
            return values[choice - 1];
        }

    }
}

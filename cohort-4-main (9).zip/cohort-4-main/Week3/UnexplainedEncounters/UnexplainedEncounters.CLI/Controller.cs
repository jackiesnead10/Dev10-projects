﻿using System;
using System.Collections.Generic;
using UnexplainedEncounters.BLL;
using UnexplainedEncounters.Core;

namespace UnexplainedEncounters.CLI
{
    public class Controller
    {
        private EncounterService service;
        private View view = new View();

        public Controller(EncounterService service)
        {
            this.service = service;
        }

        public void Run()
        {
            view.PrintHeader("Unexplained Encounters");
            MainMenuOption option;
            do
            {
                option = view.ChooseFromMenu();
                switch(option)
                {
                    case MainMenuOption.ShowAllEncounters:
                        ShowAllEncounters();
                        break;
                    case MainMenuOption.ShowEncountersByDate:
                        ShowEncountersByDate();
                        break;
                    case MainMenuOption.ShowEncountersByType:
                        ShowEncountersByType();
                        break;
                    case MainMenuOption.AddAnEncounter:
                        AddEncounter();
                        break;
                    case MainMenuOption.UpdateAnEncounter:
                        UpdateEncounter();
                        break;
                    case MainMenuOption.DeleteAnEncounter:
                        DeleteEncounter();
                        break;
                    case MainMenuOption.Exit:
                        break;
                    default:
                        view.PrintStatus(false, "[ERR] Unknown Menu Option");
                        break;
                }

            } while(option != MainMenuOption.Exit);

            view.PrintHeader("Goodbye");
        }

        private void ShowAllEncounters()
        {
            List<Encounter> encounters = service.FindAll();
            view.ShowAllEncounters(encounters);
        }

        private void ShowEncountersByDate()
        {
            DateTime date = view.GetDate(MainMenuOption.ShowEncountersByDate);
            view.PrintEncounters(service.FindByDate(date), $"No encounters on {date:MM/dd/yyyy}.");
        }

        private void ShowEncountersByType()
        {
            EncounterType type = view.GetEncounterType(MainMenuOption.ShowEncountersByType);
            view.PrintEncounters(service.FindByType(type), $"No {type} encounters found.");
        }

        private void AddEncounter()
        {
            Encounter encounter = view.MakeEncounter();
            Result<Encounter> result = service.Add(encounter);
            view.PrintResult(result);
        }

        private void UpdateEncounter()
        {
            EncounterType type = view.GetEncounterType(MainMenuOption.UpdateAnEncounter);
            List<Encounter> encounters = service.FindByType(type);
            Encounter encounter = view.ChooseEncounter(encounters);
            if(encounter != null)
            {
                encounter = view.UpdateEncounter(encounter);
                Result<Encounter> result = service.Update(encounter);
                view.PrintResult(result);
            }
        }

        private void DeleteEncounter()
        {
            EncounterType type = view.GetEncounterType(MainMenuOption.DeleteAnEncounter);
            List<Encounter> encounters = service.FindByType(type);
            Encounter encounter = view.ChooseEncounter(encounters);
            if(encounter != null)
            {
                bool success = service.DeleteById(encounter.EncounterId);
                view.PrintStatus(success, "Encounter not deleted.");
            }
        }
    }
}

﻿using System.Text;

namespace UnexplainedEncounters.CLI
{
    public enum MainMenuOption
    {
        Exit,
        ShowAllEncounters,
        ShowEncountersByDate,
        ShowEncountersByType,
        AddAnEncounter,
        UpdateAnEncounter,
        DeleteAnEncounter
    }

    static class MainMenuOptionExtensions
    {
        public static string ToLabel(this MainMenuOption option)
        {
            StringBuilder buffer = new StringBuilder();
            string value = option.ToString();

            for(int i = 0; i < value.Length; i++)
            {
                if(i > 0 && char.IsUpper(value[i]))
                {
                    buffer.Append(' ');
                }
                buffer.Append(value[i]);
            }

            return buffer.ToString();
        }
    }
}
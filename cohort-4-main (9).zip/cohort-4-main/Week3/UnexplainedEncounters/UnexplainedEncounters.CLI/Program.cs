﻿using UnexplainedEncounters.BLL;
using UnexplainedEncounters.DAL;

namespace UnexplainedEncounters.CLI
{
    class Program
    {
        static void Main(string[] args)
        {
            FileEncounterRepository repository = new FileEncounterRepository("encounters.txt");
            EncounterService service = new EncounterService(repository);
            Controller controller = new Controller(service);
            controller.Run();
        }
    }
}

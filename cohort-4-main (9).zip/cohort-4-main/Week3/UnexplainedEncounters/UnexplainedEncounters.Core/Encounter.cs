﻿using System;

namespace UnexplainedEncounters.Core
{
    public class Encounter
    {
        public int EncounterId { get; set; }
        public EncounterType EncounterType { get; set; }
        public DateTime When { get; set; }
        public string Description { get; set; }
        public bool HasWitness { get; set; }

        public Encounter() { }

        public Encounter(int encounterId, EncounterType type, DateTime when, string description, bool hasWitness)
        {
            EncounterId = encounterId;
            EncounterType = type;
            When = when;
            Description = description;
            HasWitness = hasWitness;
        }

        public override bool Equals(object obj)
        {
            return obj is Encounter encounter &&
                   EncounterId == encounter.EncounterId &&
                   EncounterType == encounter.EncounterType &&
                   When == encounter.When &&
                   Description == encounter.Description &&
                   HasWitness == encounter.HasWitness;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(EncounterId, EncounterType, When, Description, HasWitness);
        }
    }
}

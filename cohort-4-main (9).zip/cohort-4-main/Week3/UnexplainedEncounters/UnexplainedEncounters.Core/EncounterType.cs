﻿namespace UnexplainedEncounters.Core
{
    public enum EncounterType
    {
        Ufo,
        Creature,
        Voice,
        Sound,
        Vision
    }
}
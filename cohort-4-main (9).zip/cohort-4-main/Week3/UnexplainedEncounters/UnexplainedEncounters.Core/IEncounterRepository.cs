﻿using System;
using System.Collections.Generic;

namespace UnexplainedEncounters.Core
{
    public interface IEncounterRepository
    {
        List<Encounter> FindAll();
        List<Encounter> FindByDate(DateTime date);
        List<Encounter> FindByType(EncounterType type);
        Encounter FindById(int encounterId);
        Encounter Add(Encounter encounter);
        bool Update(Encounter encounter);
        bool DeleteById(int encounterId);
    }
}

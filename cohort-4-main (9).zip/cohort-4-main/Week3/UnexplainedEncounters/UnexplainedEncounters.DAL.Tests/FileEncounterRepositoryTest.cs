﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using UnexplainedEncounters.Core;

namespace UnexplainedEncounters.DAL.Tests
{
    public class FileEncounterRepositoryTest
    {
        /* Sample data. Isolate data rows to:
         * - add an Encounter,
         * - update an Encounter
         * - delete an  Encounter
         * - read Encounters
        1,4/12/2021 7:35 PM,Creature,werewolf,false
        2,4/13/2021 7:35 PM,Ufo,a darting light,true
        3,4/14/2021 7:35 AM,Ufo,a ship landed~^~I swear,false
        4,4/13/2021 7:35 PM,Voice,a raspy call from the basement,true
        5,1/12/2021 7:35 PM,Vision,a floating will-o'-the-wisp,false
         * */

        private const string SEED_FILE = "seed-data.csv";
        private const string TEST_FILE = "test-data.csv";
        // Based on the seed file, the next encounter id will be 6.
        private const int NEXT_ID = 6;

        FileEncounterRepository repository;

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            File.Copy(SEED_FILE, TEST_FILE, true);
        }

        [SetUp]
        public void SetUp()
        {
            repository = new FileEncounterRepository(TEST_FILE);
        }

        [Test]
        public void ShouldFindByIdWhenExists()
        {
            Encounter actual = repository.FindById(5);
            Assert.NotNull(actual);
        }

        [Test]
        public void ShouldNotFindByIdWhenMissing()
        {
            Encounter actual = repository.FindById(555);
            Assert.Null(actual);
        }

        [Test]
        public void ShouldNotFindSound()
        {
            List<Encounter> actual = repository.FindByType(EncounterType.Sound);
            Assert.AreEqual(0, actual.Count);
        }

        [Test]
        public void ShouldFind2Ufos()
        {
            List<Encounter> actual = repository.FindByType(EncounterType.Ufo);
            Assert.AreEqual(2, actual.Count);
        }

        [Test]
        public void ShouldHandleCommas()
        {
            Encounter encounter = repository.FindById(3);
            Assert.IsTrue(encounter.Description.Contains(','));
            Assert.IsFalse(encounter.Description.Contains("~^~"));
        }

        [Test]
        public void ShouldAdd()
        {
            Encounter encounter = MakeEncounter();
            Encounter actual = repository.Add(encounter);

            Assert.AreEqual(NEXT_ID, actual.EncounterId);

            Encounter expected = repository.FindById(NEXT_ID);
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void ShouldUpdateWhenExists()
        {
            Encounter encounter = MakeEncounter(1);
            Assert.IsTrue(repository.Update(encounter));

            Encounter expected = repository.FindById(1);
            Assert.AreEqual(expected, encounter);
        }

        [Test]
        public void ShouldNotUpdateWhenMissing()
        {
            Encounter encounter = MakeEncounter(1111);
            Assert.IsFalse(repository.Update(encounter));
        }

        [Test]
        public void ShouldDeleteWhenExists()
        {
            Assert.IsTrue(repository.DeleteById(4));
        }

        [Test]
        public void ShouldNotDeleteWhenMissing()
        {
            Assert.IsFalse(repository.DeleteById(4444));
        }

        [Test]
        public void FindByIdShouldThrow()
        {
            // lock the file
            using(FileStream locker = File.OpenWrite(TEST_FILE))
            {
                try
                {
                    // this causes an exception:
                    // System.IO.IOException : The process cannot access the file '...'
                    Encounter encounter = repository.FindById(1);
                    // if we get here, our test has failed, so fail it
                    Assert.Fail("expected an IOException");
                }
                catch(IOException)
                {
                    // this is what we want.
                }
            }
        }

        [Test]
        public void FindByTypeShouldThrow()
        {
            // lock the file
            using(FileStream locker = File.OpenWrite(TEST_FILE))
            {
                Assert.Throws<IOException>(() => repository.FindByType(EncounterType.Creature));
            }
        }

        private Encounter MakeEncounter(int id = 0)
        {
            DateTime now = DateTime.Now;
            return new Encounter
            {
                EncounterId = id,
                // our file can't handle seconds so we erase them.
                When = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, 0),
                EncounterType = EncounterType.Creature,
                Description = "a zombie vampire",
                HasWitness = true
            };
        }
    }
}

﻿# Unexplained Encounters

*Unexplained Encounters* tracks paranormal, supernatural, or other unexplained encounters in a "database".

An `Encounter` is:

- `EncounterId`: unique identifier
- `EncounterType`: Ufo, Creature, Voice, Sound, or Vision
- `When`: the date and optional time of the encounter
- `Description`: a short description of the event
- `HasWitness`: whether there were any secondary witnesses

Unexplained Encounters uses a four project/layer architecture with the following layout and classes.

```
UnexplainedEncounters
│   README.md                                 -- this README file
│   UnexplainedEncounters.sln                 -- the overall solution file
│
├───UnexplainedEncounters.BLL
│   │   EncounterService.cs                   -- service class, enforces domain rules
│   │   Result.cs                             -- since operations might not succeed, indicates success or failure and includes a data value
│   │   UnexplainedEncounters.BLL.csproj      -- The BLL project file.
│   │
│   ├───bin                                   -- binary dlls (assemblies)
│   └───obj                                   -- intermediate binary files
|
├───UnexplainedEncounters.CLI
│   │   ConsoleIO.cs                          -- universal console I/O methods, nothing tied to the domain
│   │   Controller.cs                         -- coordinates between the service and view
│   │   MainMenuOption.cs                     -- an enum value for each main menu option
│   │   Program.cs                            -- app entry point: `Main`
│   │   UnexplainedEncounters.CLI.csproj      -- the CLI project file
│   │   UnexplainedEncounters.CLI.csproj.user -- user-specific CLI project settings
│   │   View.cs                               -- domain-specific UI, uses ConsoleIO
│   │
│   ├───bin                                   -- binary dlls (assemblies)
│   └───obj                                   -- intermediate binary files
|
├───UnexplainedEncounters.Core
│   │   Encounter.cs                          -- the model (or DTO)
│   │   EncounterType.cs                      -- an enum for various types/categories of encounters
│   │   IEncounterRepository.cs               -- contract for an encounter repository
│   │   UnexplainedEncounters.Core.csproj     -- the Core project file
│   │
│   ├───bin                                   -- binary dlls (assemblies)
│   └───obj                                   -- intermediate binary files
|
└───UnexplainedEncounters.DAL
    │   FileEncounterRepository.cs            -- a file-based implementation of IEncounterRepository
    │   MemoryEncounterRepository.cs          -- an in-memory implementation of IEncounterRepository
    │   UnexplainedEncounters.DAL.csproj      -- the DAL project file
    │
    ├───bin                                   -- binary dlls (assemblies)
    └───obj                                   -- intermediate binary files
```

As a high-level diagram:

![The four layers](layers.svg)

## Technical Features

### MVC

Unexplained Encounters uses the [Model/View/Controller design pattern](https://en.wikipedia.org/wiki/Model%E2%80%93view%E2%80%93controller) (MVC) in its CLI project. The `Controller` class is not allowed to directly access the console. Only the `View` (domain UI) or `ConsoleIO` (universal console UI) can access the console.

The "M" in MVC is a model. Models are the application's DTOs, in this case `Encounter`. Model operations are managed by the `EncounterService`. Models can also be generated from scratch by the `View`. (The repository plays an important role here, but isn't part of the MVC pattern.)

The `Controller` coordinates action between the `EncounterService` and `View`. The `Controller` is sort of like a fast-food cashier. A cashier receives direction from the customer (user) and keeps the customer up-to-date about what's happen with their food. The cashier is a controller between the view (customer input/output) and service (the kitchen).

Below is a sequence diagram for an MVC "add" operation.

![MVC sequence diagram for an add operation](mvc-sequence.svg)

### Enums

Unexplained Encounters uses two enums.

The first, `EncounterType`, is the type of encounters possible.

The second, `MainMenuOption`, drives the main menu without the need for "magic" numbers. See `View.ChooseFromMenu` and `Controller.Run` for an idea of how this might work.

### Other Bits

The `MainMenuOption.cs` files includes an [extension method](https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/classes-and-structs/extension-methods) inside a static extension class. Extension methods are useful when we want a method-like syntax for a value type or a third-party type that we don't control.

The `View` includes a static import: `using static UnexplainedEncounters.CLI.ConsoleIO;`, which allows us to reference the static methods inside `ConsoleIO` without using its class name.

The `FileEncounterRepository` has strong opinions about state management. It doesn't use an in-memory list or dictionary. If we store encounters in a field or property, it's very likely that the collection and the file (database) can get out-of-synch. That's bad.

The `FileEncounterRepository` also tries to remove dangerous characters (commas) before it writes to the file. Then it restores the commas when it reads. Can you think of better ways to accomplish this? With a bit of true "parsing" (not happening in `FileEncounterRepository`), we can guarantee that there's no way to corrupt the file. Any ideas?

`EncounterService` does its best to validate an `Encounter` before it's saved and returns a `Result` to indicate success or failure. It doesn't bother with a `Result` for read operations.
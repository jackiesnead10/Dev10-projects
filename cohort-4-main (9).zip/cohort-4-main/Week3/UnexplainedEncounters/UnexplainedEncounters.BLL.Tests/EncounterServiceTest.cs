﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using UnexplainedEncounters.Core;

namespace UnexplainedEncounters.BLL.Tests
{
    public class EncounterServiceTest
    {
        EncounterService service;

        [SetUp]
        public void SetUp()
        {
            service = new EncounterService(new StubEncounterRepository());
        }

        [TestCase(EncounterType.Creature, 2)]
        [TestCase(EncounterType.Ufo, 3)]
        [TestCase(EncounterType.Vision, 0)]
        [TestCase(EncounterType.Voice, 0)]
        [TestCase(EncounterType.Sound, 2)]
        public void ShouldFindByType(EncounterType type, int expected)
        {
            List<Encounter> encounters = service.FindByType(type);
            Assert.AreEqual(expected, encounters.Count);
        }

        [Test]
        public void FindAllShouldFind7()
        {
            List<Encounter> encounters = service.FindAll();
            Assert.AreEqual(7, encounters.Count);
        }

        [TestCase(2020, 1, 1, 2)]
        [TestCase(2021, 1, 1, 3)]
        [TestCase(2021, 2, 2, 1)]
        [TestCase(2020, 2, 2, 1)]
        [TestCase(2005, 2, 2, 0)]
        [TestCase(2004, 2, 2, 0)]
        public void ShouldFindByDate(int year, int month, int day, int expected)
        {
            List<Encounter> encounters = service.FindByDate(new DateTime(year, month, day));
            Assert.AreEqual(expected, encounters.Count);
        }

        [Test]
        public void AddShouldRejectNull()
        {
            Result<Encounter> result = service.Add(null);
            Assert.IsFalse(result.IsSuccess);
            Assert.AreEqual(1, result.Messages.Count);
            Assert.AreEqual("encounter cannot be null.", result.Messages[0]);
        }

        [Test]
        public void AddShouldRejectWhitespaceDescription()
        {
            Encounter encounter = MakeValidEncounter();
            encounter.Description = " \t  \n\r\n";
            Result<Encounter> result = service.Add(encounter);
            Assert.IsFalse(result.IsSuccess);
            Assert.AreEqual(1, result.Messages.Count);
            Assert.AreEqual("Description is required.", result.Messages[0]);
        }

        [Test]
        public void AddShouldRejectFutureWhen()
        {
            Encounter encounter = MakeValidEncounter();
            encounter.When = DateTime.Now.AddMonths(2);
            Result<Encounter> result = service.Add(encounter);
            Assert.IsFalse(result.IsSuccess);
            Assert.AreEqual(1, result.Messages.Count);
            Assert.AreEqual("When cannot be in the future.", result.Messages[0]);
        }

        [Test]
        public void AddShouldRejectOldWhen()
        {
            Encounter encounter = MakeValidEncounter();
            encounter.When = DateTime.Now.AddYears(-105);
            Result<Encounter> result = service.Add(encounter);
            Assert.IsFalse(result.IsSuccess);
            Assert.AreEqual(1, result.Messages.Count);
            Assert.AreEqual("When is too far in the past.", result.Messages[0]);
        }

        [Test]
        public void AddShouldRejectDuplicate()
        {
            Encounter encounter = new Encounter(0, EncounterType.Ufo, new DateTime(2021, 1, 1), "Encounter #3", false);
            Result<Encounter> result = service.Add(encounter);
            Assert.IsFalse(result.IsSuccess);
            Assert.AreEqual(1, result.Messages.Count);
            Assert.AreEqual("Encounter is a duplicate.", result.Messages[0]);
        }

        [Test]
        public void AddShouldRejectMultipleInvalid()
        {
            Encounter encounter = new Encounter();
            encounter.When = DateTime.Now.AddDays(10);
            Result<Encounter> result = service.Add(encounter);
            Assert.IsFalse(result.IsSuccess);
            Assert.AreEqual(2, result.Messages.Count);
        }

        [Test]
        public void ShouldAdd()
        {
            Encounter encounter = MakeValidEncounter();
            Result<Encounter> result = service.Add(encounter);
            Assert.IsTrue(result.IsSuccess);
            Assert.AreEqual(0, result.Messages.Count);
            Assert.NotNull(result.Value);
            Assert.AreEqual(8, result.Value.EncounterId);
        }

        [Test]
        public void ShouldUpdateWhenExists()
        {
            Encounter encounter = MakeValidEncounter(3);
            Result<Encounter> result = service.Update(encounter);
            Assert.IsTrue(result.IsSuccess);
        }

        [Test]
        public void ShouldNotUpdateWhenMissing()
        {
            Encounter encounter = MakeValidEncounter(33);
            Result<Encounter> result = service.Update(encounter);
            Assert.IsFalse(result.IsSuccess);
            Assert.AreEqual(1, result.Messages.Count);
            Assert.AreEqual("encounter was not updated.", result.Messages[0]);
        }

        [Test]
        public void ShouldDeleteWhenExists()
        {
            Assert.IsTrue(service.DeleteById(5));
        }

        [Test]
        public void ShouldNotDeleteWhenMissing()
        {
            Assert.IsFalse(service.DeleteById(555));
        }

        private Encounter MakeValidEncounter(int id = 0)
        {
            DateTime now = DateTime.Now;
            return new Encounter
            {
                EncounterId = id,
                // our file can't handle seconds so we erase them.
                When = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, 0),
                EncounterType = EncounterType.Creature,
                Description = "a zombie vampire",
                HasWitness = true
            };
        }
    }
}

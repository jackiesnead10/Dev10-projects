﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFMigrationDemo.CORE
{
    public class Account
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Balance { get; set; }
        public List<Transaction> Transactions { get; set; }
        public List<AccountContact> AccountContacts { get; set; }
        public List<AccountEmployee> AccountEmployee { get; set; }
    }

    public class AccountContact
    {
        public int AccountId { get; set; }
        public int ContactId { get; set; }

        public Account Account { get; set; }
        public Contact Contact { get; set; }
    }
    public class AccountEmployee
    {
        public int AccountId { get; set; }
        public int EmployeeId { get; set; }

        public DateTime? StartDate { get; set; }
        public Account Account { get; set; }
        public Employee Employee { get; set; }

    }
    public class Employee
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public List<AccountEmployee> AccountEmployee { get; set; }
    }
    public class Contact
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public List<AccountContact> AccountContacts { get; set; }

    }
}

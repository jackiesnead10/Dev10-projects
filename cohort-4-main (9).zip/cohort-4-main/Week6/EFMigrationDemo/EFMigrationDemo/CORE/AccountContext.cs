﻿using Microsoft.EntityFrameworkCore;

namespace EFMigrationDemo.CORE
{
    public class AccountContext : DbContext
    {
        public DbSet<Account> Accounts {get;set;}
        public DbSet<Transaction> Transactions {get;set;}
        public DbSet<Contact> Contacts {get;set;}
        public DbSet<Employee> Employees {get;set;}

        public DbSet<AccountContact> AccountContacts {get;set;}
        public DbSet<AccountEmployee> AccountEmployee {get;set;}
        public AccountContext()
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AccountContact>().HasKey(ac => new {ac.AccountId, ac.ContactId});
            modelBuilder.Entity<AccountEmployee>().HasKey(ac => new {ac.AccountId, ac.EmployeeId});
            base.OnModelCreating(modelBuilder);
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=localhost;Database=AccountRus;User Id=sa;Password=YOUR_strong_*pass4w0rd*;");
            base.OnConfiguring(optionsBuilder);
        }
    }
}

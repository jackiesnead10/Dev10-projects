﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace EFMigrationDemo.Migrations
{
    public partial class add_StartDate_Column : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AccountEmployee_Accounts_AccountsId",
                table: "AccountEmployee");

            migrationBuilder.DropForeignKey(
                name: "FK_AccountEmployee_Employees_EmployeesId",
                table: "AccountEmployee");

            migrationBuilder.RenameColumn(
                name: "EmployeesId",
                table: "AccountEmployee",
                newName: "EmployeeId");

            migrationBuilder.RenameColumn(
                name: "AccountsId",
                table: "AccountEmployee",
                newName: "AccountId");

            migrationBuilder.RenameIndex(
                name: "IX_AccountEmployee_EmployeesId",
                table: "AccountEmployee",
                newName: "IX_AccountEmployee_EmployeeId");

            migrationBuilder.AddColumn<DateTime>(
                name: "StartDate",
                table: "AccountEmployee",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_AccountEmployee_Accounts_AccountId",
                table: "AccountEmployee",
                column: "AccountId",
                principalTable: "Accounts",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_AccountEmployee_Employees_EmployeeId",
                table: "AccountEmployee",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AccountEmployee_Accounts_AccountId",
                table: "AccountEmployee");

            migrationBuilder.DropForeignKey(
                name: "FK_AccountEmployee_Employees_EmployeeId",
                table: "AccountEmployee");

            migrationBuilder.DropColumn(
                name: "StartDate",
                table: "AccountEmployee");

            migrationBuilder.RenameColumn(
                name: "EmployeeId",
                table: "AccountEmployee",
                newName: "EmployeesId");

            migrationBuilder.RenameColumn(
                name: "AccountId",
                table: "AccountEmployee",
                newName: "AccountsId");

            migrationBuilder.RenameIndex(
                name: "IX_AccountEmployee_EmployeeId",
                table: "AccountEmployee",
                newName: "IX_AccountEmployee_EmployeesId");

            migrationBuilder.AddForeignKey(
                name: "FK_AccountEmployee_Accounts_AccountsId",
                table: "AccountEmployee",
                column: "AccountsId",
                principalTable: "Accounts",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_AccountEmployee_Employees_EmployeesId",
                table: "AccountEmployee",
                column: "EmployeesId",
                principalTable: "Employees",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}

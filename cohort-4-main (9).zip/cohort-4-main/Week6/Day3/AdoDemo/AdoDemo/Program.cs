﻿using AdoDemo.DAL;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;

namespace AdoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
         

            //GravelFamilyContext context = GravelFamilyContext.GetDBContext();

            //IEmployeeRepository employeeRepository = new EFEmployeeRepository(context);
            //IProjectRepository projectRepository = new ProjectRepository(context);
            ////IEmployeeRepository employeeRepository = new EmployeeRepository(sqlConnectionString);
            //EmployeeController controller = new EmployeeController(employeeRepository);
            ////controller.Run();

            ////var query = context.Employee
            ////                .Include(e => e.ProjectEmployee).ThenInclude(pe => pe.Project).ThenInclude(r=> r.Customer)
            ////                .Include(e=> e.ProjectEmployee).ThenInclude(pe => pe.Project).ThenInclude(r=> r.ProjectItems).ThenInclude(pi => pi.Item)
            ////                .Where(e => e.EmployeeId == 1)
            ////                .ToQueryString();

            //List<Project> projects = projectRepository.ReadAll();

            ///* ConsoleIO.DisplayProjects(projects) */ 
            //foreach (Project project in projects)
            //{
            //    Console.WriteLine(project.ProjectId);
            //    foreach (Employee employee in project.Employees)
            //    {
            //        Console.WriteLine(employee.FirstName + " " + employee.LastName);
            //    }
            //}

            var builder = new ConfigurationBuilder();

            // Configure Builder
            builder.SetBasePath(Directory.GetCurrentDirectory());
            //builder.AddJsonFile("appsettings.json", false, true);
            builder.AddCommandLine(args);
            builder.AddEnvironmentVariables();
             //  string sqlConnectionString = Environment.GetEnvironmentVariable("GravelFamily", EnvironmentVariableTarget.User);
            // Instantiate reader
            var config = builder.Build();
            var connectionString = config["OS"];
            Console.WriteLine(connectionString);
        }
    }
}

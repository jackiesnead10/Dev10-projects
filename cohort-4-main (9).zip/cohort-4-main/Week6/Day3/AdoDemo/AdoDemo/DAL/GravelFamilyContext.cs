﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoDemo.DAL
{
    public class GravelFamilyContext : DbContext
    {
        public DbSet<Employee> Employee { get; set; }
        public DbSet<Project> Project { get; set; }
        public DbSet<Customer> Customer { get; set; }
        public DbSet<Item> Item { get; set; }

        /* Bridge Tables */

        public DbSet<ProjectItem> ProjectItem { get; set; }
        public DbSet<ProjectEmployee> ProjectEmployee { get; set; }


        public GravelFamilyContext(DbContextOptions options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Other configuration left out to focus on many-to-many

            modelBuilder.Entity<ProjectEmployee>().HasKey(pe => new {pe.EmployeeId, pe.ProjectId});
            modelBuilder.Entity<ProjectItem>().HasKey(pe => new {pe.ItemId, pe.ProjectId});
            
            //modelBuilder.Entity<Employee>()
            //            .HasMany(x => x.Projects)
            //            .WithMany(x => x.Employees)
            //             .UsingEntity<Dictionary<string, object>>(
            //                    "ProjectEmployee", // <-- Name of the table
            //                    j => j
            //                        .HasOne<Project>() // <-- from the bridget table, it has one project
            //                        .WithMany() // <-- that can have many entries in the bridge table
            //                        .HasForeignKey("ProjectId") // <-- it's column name is ProjectId
            //                    ,
            //                    j => j
            //                        .HasOne<Employee>()
            //                        .WithMany()
            //                        .HasForeignKey("EmployeeId")
            //                );


        }
        public static GravelFamilyContext GetDBContext()
        {
            var options = new DbContextOptionsBuilder<GravelFamilyContext>()
        .UseSqlServer("Server=localhost;Database=GravelFamily;User Id=sa;Password=YOUR_strong_*pass4w0rd*")
        .Options;
            return new GravelFamilyContext(options);
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace AdoDemo
{
    public class Project
    {
        public int ProjectId { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int CustomerId { get; set; }
        public List<Employee> Employees { get; set; }
        public List<ProjectItem> ProjectItems { get; set; }
        public Customer Customer { get; set; }
    }
}

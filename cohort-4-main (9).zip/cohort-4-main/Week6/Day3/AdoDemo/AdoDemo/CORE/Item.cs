﻿using System.Collections.Generic;

namespace AdoDemo
{
    public class Item
    {
        public int ItemId { get; set; }
        public string Name { get; set; }
        public int CategoryId { get; set; }
        public int UnitId { get; set; }
        public decimal PricePerUnit { get; set; }
        public List<ProjectItem> ProjectItems {get;set;}
    }
}

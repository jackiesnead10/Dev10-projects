﻿using AdoDemo.DAL;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace AdoDemo
{
    public interface IEmployeeRepository
    {
        Employee CreateEmployee(Employee employee);
        List<Employee> ReadAll();

        void Update(Employee employee);

        void Delete(int employeeId);
    }
    public interface IProjectRepository
    {
        List<Project> ReadAll();

    }
    public class ProjectRepository : IProjectRepository
    {
        private GravelFamilyContext context;

        public ProjectRepository(GravelFamilyContext context)
        {
            this.context = context;
        }

        public List<Project> ReadAll()
        {
            return context.Project.Include(p => p.Employees).ToList();
        }
    }
}
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;

namespace AdoDemo.Tests
{
    public class EFEmployeeTests
    {
        EFEmployeeRepository repository;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<GravelFamilyContext>()
       .UseInMemoryDatabase("TestDatabase")
       .Options;

            var context = new GravelFamilyContext(options);
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            repository = new EFEmployeeRepository(context);
        }

        [Test]
        public void ShouldAddEmployee()
        {
            Employee employee = new Employee(){FirstName = "James", LastName = "Bond"};
            repository.CreateEmployee(employee);
            Assert.NotZero(employee.EmployeeId);
        }
    }
}
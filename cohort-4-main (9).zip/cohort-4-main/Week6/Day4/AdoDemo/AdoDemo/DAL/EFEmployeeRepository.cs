﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace AdoDemo
{
    public class EFEmployeeRepository : IEmployeeRepository
    {
        private GravelFamilyContext _context;

        public EFEmployeeRepository(GravelFamilyContext context)
        {
            _context = context;
        }

        public Employee CreateEmployee(Employee employee)
        {
            _context.Employee.Add(employee);
            _context.SaveChanges();
            return employee;
        }

        public void Delete(int employeeId)
        {
            _context.Employee.Remove(_context.Employee.Find(employeeId));
            _context.SaveChanges();
        }

        public List<Employee> ReadAll()
        {
            return _context.Employee.AsNoTracking().ToList();
        }

        public void Update(Employee employee)
        {
            _context.Employee.Update(employee);
            _context.SaveChanges();
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;

namespace AdoDemo
{
    public class GravelFamilyContext : DbContext
    {
        public DbSet<Employee> Employee { get; set; }


        public GravelFamilyContext(DbContextOptions options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Other configuration left out to focus on many-to-many




        }
        public static GravelFamilyContext GetDBContext()
        {
            var options = new DbContextOptionsBuilder<GravelFamilyContext>()
        .UseSqlServer("Server=localhost;Database=GravelFamily;User Id=sa;Password=YOUR_strong_*pass4w0rd*")
        .Options;
            return new GravelFamilyContext(options);
        }
    }
}

﻿using System;

namespace TaskManagerV2.Core
{
    public class Class1
    {
    }
}

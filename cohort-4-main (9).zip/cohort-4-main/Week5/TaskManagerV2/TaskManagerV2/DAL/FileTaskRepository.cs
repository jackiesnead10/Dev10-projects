﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TaskManagerV2.Core;

namespace TaskManagerV2.DAL
{
    public class FileTaskRepository : ITaskRepository
    {
        private string _fileName;
        private List<Task> tasks;
        public FileTaskRepository(string fileName) { }

        private void Load() { }
        private void Save() { }
        public Task CreateTask()
        {
            throw new NotImplementedException();
        }

        public List<Task> ReadAll()
        {
            throw new NotImplementedException();
        }

        public List<Task> ReadAllByEmployeeId(int employeeId)
        {
            throw new NotImplementedException();
        }

        public Task ReadById(int taskId)
        {
            throw new NotImplementedException();
        }

        public void Update()
        {
            throw new NotImplementedException();
        }
    }
}
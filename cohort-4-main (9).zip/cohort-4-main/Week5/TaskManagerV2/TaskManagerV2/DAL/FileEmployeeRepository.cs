﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TaskManagerV2.Core;
using System.IO;
namespace TaskManagerV2.DAL
{
    public class FileEmployeeRepository : IEmployeeRepository
    {
        private string _fileName;
        private List<Employee> _employees;
        public FileEmployeeRepository(string fileName)
        {
            _fileName = fileName;
            Load();
        }
        private void Load()
        {
            _employees = new List<Employee>();
            if (!File.Exists(_fileName))
            {
                return;
            }
            else
            {
                using (StreamReader sr = new StreamReader(_fileName))
                {
                    string[] lines = sr.ReadToEnd().Split("\n");
                    if (lines.Length < 2) return;
                    for (int i = 1; i < lines.Length; i++)
                    {
                        string[] fields = lines[i].Split(",");
                        if (fields.Length != 2) continue;

                        Employee employee = new Employee();
                        employee.Id = int.Parse(fields[0]);
                        employee.EmployeeName = fields[1];
                        _employees.Add(employee);
                    }
                }
            }
        }
        public List<Employee> ReadAllEmployees()
        {
            return _employees;
        }

        public Employee ReadById(int employeeId)
        {
           return _employees.FirstOrDefault(e => e.Id == employeeId);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TaskManagerV2.DAL;
using TaskManagerV2.Core;

namespace TaskManagerV2.BLL
{
    public class EmployeeService
    {
        private IEmployeeRepository _employeeRepository;
        public EmployeeService(IEmployeeRepository employeeRepository)
        {

        }
        public Result<List<Employee>> ReadAllEmployees()
        {
            throw new NotImplementedException();

        }
        public Result<Employee> ReadEmployeeById(int employeeId)
        {
            throw new NotImplementedException();

        }
    }
}
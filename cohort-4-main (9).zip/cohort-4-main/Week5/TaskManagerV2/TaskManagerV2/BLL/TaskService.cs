﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TaskManagerV2.Core;
using TaskManagerV2.DAL;

namespace TaskManagerV2.BLL
{
    public class TaskService
    {
        private ITaskRepository _taskRepository;
        private IEmployeeRepository _employeeRepository;
        public TaskService(ITaskRepository taskRepository, IEmployeeRepository employeeRepository) { }
        public Result<List<Task>> ViewAllTask()
        {
            throw new NotImplementedException();
        }
        public Result<List<Task>> ViewAllTaskByEmployee(int employeeId)   {
            throw new NotImplementedException();
        }
        public Result<Task> AddTask(Task Task)   {
            throw new NotImplementedException();
        }
        public Result AssignTask(Task task)   {
            throw new NotImplementedException();
        }
        public Result CompleteTask(int taskId)   {
            throw new NotImplementedException();
        }
        public Result<IGrouping<Employee, int>> GenerateEmployeeTaskReport()   {
            throw new NotImplementedException();
        }
    }
}
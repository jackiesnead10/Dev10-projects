﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskManagerV2.Core
{
    public class Result
    {
        public string Message { get; set; }
        public bool Success { get; set; }
    }
    public class Result<T> : Result
    {
        public T Data { get; set; }
    }
}
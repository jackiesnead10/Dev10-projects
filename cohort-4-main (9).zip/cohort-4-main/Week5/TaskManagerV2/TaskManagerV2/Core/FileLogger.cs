﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskManagerV2.Core
{
    public class FileLogger : ILogger
    {
        private string _fileName;
        public FileLogger(string fileName)
        {
            _fileName = fileName;
        }
        public void Log(string log)
        {
            throw new NotImplementedException();
        }
    }
}
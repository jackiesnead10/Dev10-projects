﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskManagerV2.Core
{
    public interface ITaskRepository
    {
        Task CreateTask();
        List<Task> ReadAll();
        Task ReadById(int taskId);
        List<Task> ReadAllByEmployeeId(int employeeId);
        void Update();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskManagerV2.Core
{
    public class Employee
    {
        public int Id {get;set;}
        public string EmployeeName {get;set;}

        public override bool Equals(object obj)
        {
            return obj is Employee employee &&
                   Id == employee.Id &&
                   EmployeeName == employee.EmployeeName;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Id, EmployeeName);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TaskManagerV2.Core;

namespace TaskManagerV2
{
    public class ConsoleIO
    {
        public void Display(string message, ConsoleColor color)
        {
            throw new System.NotImplementedException();
        }

        public Task PromptUserTask(string message)
        {
            throw new System.NotImplementedException();
        }

        public Task PromptUserChoiceTasks(List<Task> tasks)
        {
            throw new System.NotImplementedException();
        }

        public int PromptUserInt(string message)
        {
            throw new System.NotImplementedException();
        }

        public DateTime PromptUserDateTime(string message)
        {
            throw new System.NotImplementedException();
        }

        public Employee PromptUserChoiceEmployees(List<Employee> employees)
        {
            throw new System.NotImplementedException();
        }
    }
}
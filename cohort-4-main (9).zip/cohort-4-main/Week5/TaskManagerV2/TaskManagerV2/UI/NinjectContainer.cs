﻿using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TaskManagerV2.Core;
using TaskManagerV2.DAL;
namespace TaskManagerV2
{
    public class NinjectContainer
    {
        public static IKernel Kernal { get; private set; }
        public static void Configure()
        {
            Kernal = new StandardKernel();
            Kernal.Bind<IEmployeeRepository>().To<FileEmployeeRepository>().WithConstructorArgument("fileName", "employees.csv");
            Kernal.Bind<ITaskRepository>().To<FileTaskRepository>().WithConstructorArgument("fileName", "tasks.csv");

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TaskManagerV2.Core;
using TaskManagerV2.BLL;

namespace TaskManagerV2
{
    public class Controller
    {
        private TaskService _taskService;
        private EmployeeService _employeeService;
        private ConsoleIO _view;

        public Controller(TaskService taskService, EmployeeService employeeService, ConsoleIO view)
        {
            throw new System.NotImplementedException();
        }

        public void Run()
        {
            throw new System.NotImplementedException();
        }

        private void ViewAllTasks()
        {
            throw new System.NotImplementedException();
        }

        private void ViewEmployeeTask()
        {
            throw new System.NotImplementedException();
        }

        private void AddTask()
        {
            throw new System.NotImplementedException();
        }

        private void AssignTask()
        {
            throw new System.NotImplementedException();
        }

        private void UpdateTask()
        {
            throw new System.NotImplementedException();
        }

        private void DisplayEmployeeTaskReport()
        {
            throw new System.NotImplementedException();
        }
    }
}
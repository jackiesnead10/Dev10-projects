﻿using System;
using Ninject;

namespace TaskManagerV2
{
    class Program
    {
        static void Main(string[] args)
        {
           NinjectContainer.Configure();
           Controller controller = NinjectContainer.Kernal.Get<Controller>();
           controller.Run();
        }
    }
}

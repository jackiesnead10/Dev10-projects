using NUnit.Framework;
using TaskManagerV2.Core;
using TaskManagerV2.DAL;
namespace TaskManagerV2.Tests
{
    public class FileEmployeeRepositoryTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void ShouldCreateNewFileEmployeeRepositoryWithEmptyFile()
        {
            IEmployeeRepository target = new FileEmployeeRepository("./testEmployeesFile.csv");
            
            Assert.IsInstanceOf(typeof(IEmployeeRepository), target);
            Assert.AreEqual(0, target.ReadAllEmployees().Count);
        }
         [Test]
        public void ShouldCreateNewFileEmployeeRepositoryWithExsitingEmployeeFile()
        {
            IEmployeeRepository target = new FileEmployeeRepository("./seedEmployeesFile.csv");
            Employee expectedEmployee = new Employee();
            expectedEmployee.Id = 1;
            expectedEmployee.EmployeeName = "Batman";
            Assert.AreEqual(1, target.ReadAllEmployees().Count);
            Assert.AreEqual(expectedEmployee, target.ReadAllEmployees()[0]);
        }

        [Test]
        public void ShouldCreateNewFileEmployeeRepositoryWithNonExsitingEmployeeFile()
        {
            IEmployeeRepository target = new FileEmployeeRepository("./NoEmployeeFile.csv");
           
            Assert.AreEqual(0, target.ReadAllEmployees().Count);
            
        }

        [Test]
         public void ShouldReturnExpectedEmployeeById()
        {
            IEmployeeRepository target = new FileEmployeeRepository("./seedEmployeesFile.csv");
            Employee expectedEmployee = new Employee();
            expectedEmployee.Id = 1;
            expectedEmployee.EmployeeName = "Batman";

            Assert.AreEqual(expectedEmployee, target.ReadById(1));
        }

           [Test]
         public void ShouldReturnNullEmployeeById()
        {
            IEmployeeRepository target = new FileEmployeeRepository("./seedEmployeesFile.csv");
      

            Assert.IsNull(target.ReadById(9001));
        }
    }
}
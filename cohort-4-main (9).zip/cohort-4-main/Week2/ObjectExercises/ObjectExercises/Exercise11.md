# Exercise11

1. Add a class to the project named `Power` which represents a hero's super power.
2. Add a property `string Name`: the super power's name. 
	Name has a public `get` and private `set`.
3. Add a constructor that accepts a string name and sets the Name property.
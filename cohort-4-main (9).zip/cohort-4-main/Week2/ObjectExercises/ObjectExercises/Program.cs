﻿using System;

namespace ObjectExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Object Exercises");
        }
    }
}

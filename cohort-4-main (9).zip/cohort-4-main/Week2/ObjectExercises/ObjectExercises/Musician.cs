﻿namespace ObjectExercises
{
    public class Musician
    {
        private int rating;
        public string Name { get; private set; }

        /// <summary>
        /// Represents a musical artist.
        /// </summary>
        /// <param name="name">The name of the musician.</param>
        /// <param name="rating">A number representing how much a musician is loved relative to other musicians.</param>
        public Musician(string name, int rating)
        {
            Name = name;
            this.rating = rating;
        }
    }
}

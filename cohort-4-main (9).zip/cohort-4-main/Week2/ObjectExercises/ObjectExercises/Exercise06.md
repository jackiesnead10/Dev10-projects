# Exercise06

1. Add a class to this project named `Balloon`.

    Right click the project in the *Solution Explorer*. Select *Add* -> *New Item*. In the *Add New Item* dialog, select *Class* and name the class `Balloon`.

2. Add two properties:

    - `string Color`: balloon's color.
        Color has a public `get` and private `set`.

    - `double Psi`: balloon's pressure in lbs/sq inch.
        Psi has a public `get` and private `set`.

3. Add a constructor that accepts a `string color` and sets the Color property. Do not set Psi. (Psi will always have its default value 0.0)
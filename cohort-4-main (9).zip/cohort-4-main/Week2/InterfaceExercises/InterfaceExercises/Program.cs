﻿using System;

namespace InterfaceExercises
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Interface Exercises.");
        }
    }
}

﻿namespace InterfaceExercises
{
    class Person : Wallet
    {
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public string FullName => $"{FirstName} {LastName}";

        public Person(string firstName, string lastName)
            : base(0.0M, $"{firstName}'s Wallet")
        {
            FirstName = firstName;
            LastName = lastName;
        }
    }
}

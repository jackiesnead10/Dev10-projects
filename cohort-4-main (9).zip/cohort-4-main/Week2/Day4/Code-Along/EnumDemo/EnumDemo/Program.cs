﻿using System;
using System.Xml.Serialization;

namespace EnumDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Array values = Enum.GetValues(typeof(Colors));
            for (int i = 0; i < values.Length; i++)
            {
                Console.WriteLine($"{i+1} {values.GetValue(i).ToString()}");
            }

            Console.WriteLine("Please Enter a choice:");

            string input = Console.ReadLine();
            if (input != null)
            {
                //Colors choice = (Colors)Enum.Parse(typeof(Colors), input, true);
                Type myType = typeof(Colors);
                
                Colors choice = Enum.Parse<Colors>(input, true);
                Console.WriteLine(choice.ToString());
                DisplayChoice(choice);

                Console.WriteLine("Please enter 1-3");
                int newChoice = int.Parse(Console.ReadLine());
                choice = (Colors) (newChoice-1);
                DisplayChoice(choice);

            }
        }

        public static void DisplayChoice(Colors color)
        {
            switch (color)
            {
                case Colors.RED:
                    Console.WriteLine("Like superman's home world sun!");
                    break;
                case Colors.BLUE:
                    Console.WriteLine("Clear skies!");
                    break;
                case Colors.GREEN:
                    Console.WriteLine("Always greener on the other side");
                    break;
                default:
                    Console.WriteLine("Invalid input");
                    break;
                    ;
            }
        }
    }
}

# Exercise03

1. Find the `Card` class in this project.
2. Complete the tasks listed inside.
3. Find the `CardValidator` class in this project.
4. Complete the tasks inside.
# Exercise02

1. Add a `Rank` enum to the `EnumExercises` project. 
This enum represents the 13 ranks in a 52-card French Deck: https://en.wikipedia.org/wiki/Standard_52-card_deck
2. Ranks include Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack, Queen, and King. Use proper enum naming conventions.
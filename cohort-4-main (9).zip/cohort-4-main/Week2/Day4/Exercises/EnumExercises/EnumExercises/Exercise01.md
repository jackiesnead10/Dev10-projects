# Exercise01

1. Add a `Suit` enum to the `EnumExercises` project. 
This enum represents the four suits in a 52-card French Deck: https://en.wikipedia.org/wiki/Standard_52-card_deck
2. Suits include spades, hearts, diamonds, and clubs. Use proper enum naming conventions.
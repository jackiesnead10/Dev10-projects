﻿using System;

namespace EnumExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enum Exercises\n");
            CardValidator.Validate();
            TwoCardHandValidator.Validate();
        }
    }
}

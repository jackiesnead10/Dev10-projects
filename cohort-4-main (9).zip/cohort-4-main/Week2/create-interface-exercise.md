# Create Your Own Interface

1. Create an interface that enforces a contract for calculating an average. There are several ways to calculate an average (mean). See here: https://en.wikipedia.org/wiki/Average#Summary_of_types. Our interface, maybe `IAverager`, needs a method contract that accepts a `decimal[]` as a parameter (input) and returns a `decimal` (output). Any implementing class should calculate an average from the decimal array and return it.

2. Add two `IAverager` concrete class implementations. No need to get fancy with concrete implementations. Start with the traditional arithmetic mean (sum of elements divided by their total) and the median (the middle value in an ordered sequence).

    Hint for median: sort the `decimal[]` with [Array.Sort](https://docs.microsoft.com/en-us/dotnet/api/system.array.sort?view=net-5.0) then find the middle value.

    ```cs
    decimal[] numbers = { 103.1M, 2.2M, 3.3M , 1.1M, -5M};
    Array.Sort(numbers); // sort an array in-place with Array.Sort
    Console.WriteLine(string.Join(",", numbers));
    ```

3. Test your implementations in `Program.cs`. Make sure they're working properly.

4. Create a `QuizResult` class. A `QuizResult` tracks two bits of data: a student's name and a decimal test score. Student name and score can be properties. It's also convenient to pass them via constructor so `QuizResult` is easy to instantiate.

5. Create a `Quiz` class. 

    The `Quiz` class has the following fields and corresponding constructor arguments:

    - `IAverager` - used to calculated average quiz scores
    - `QuizResult[]` - an array of `QuizResult`s that represent student scores

    The `Quiz` class has the following methods:

    - `decimal GetAverage()` - returns the average quiz score using the `IAverager` field. (Hint: create a new `decimal[]` the same size as the `QuizResult[]`. Copy the scores into the new array and pass it to the `IAverager`'s calculation method.)
    - `string GetStudentWithHighestScore` - returns the name of the student with the highest score.

6. Back in `Program.cs`:

    1. instantiate several `QuizResult` objects and add them to an array.
    2. instantiate an instance of one of your `IAverager` implementations.
    3. instantiate a `Quiz` object, passing the `QuizResult[]` and `IAverager` as constructor arguments.
    4. write the results of `GetAverage` and `GetStudentWithHighestScore` to the console.

7. In `Program.cs`, swap `IAverager` implementations and run the program again.

## Questions

- Why not just let `Quiz` implement `IAverager`?
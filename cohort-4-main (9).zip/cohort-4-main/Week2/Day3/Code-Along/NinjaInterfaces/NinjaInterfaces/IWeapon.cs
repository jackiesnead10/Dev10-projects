﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NinjaInterfaces
{
    public interface IWeapon
    {
        int Damage { get; set; }

        string Output();
    }
}

﻿namespace NinjaInterfaces
{
    public interface IFighter
    {
        int Attack();
    }
}
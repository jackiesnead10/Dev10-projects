﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NinjaInterfaces
{
    public class GunSlinger : IFighter, IToken
    {
        public int Attack()
        {
            return 10;
        }

        public int Health { get; set; }
        public int Power { get; set; }
    }
}

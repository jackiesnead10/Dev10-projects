﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NinjaInterfaces
{
    public class Wand : IWeapon
    {
        public int Damage { get; set; }

        public string Output()
        {
            return $"You cast a spell for {Damage} damage!";
        }
    }
}
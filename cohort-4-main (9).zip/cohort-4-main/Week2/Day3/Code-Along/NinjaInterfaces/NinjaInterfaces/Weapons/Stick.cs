﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NinjaInterfaces
{
    public class Stick : IWeapon
    {
        public int Damage { get; set; }
        public string Output()
        {
            return "A wise man once said, \"Speak softly and carry a big stick.\"";
        }
    }
}\
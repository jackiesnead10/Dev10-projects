using System;
using System.Text;

namespace NinjaInterfaces
{
    public class Excalibur : IWeapon
    {
        public int Damage { get; set;}
    
        public string Output()
        {
            return "You cannot escape EXCALIBUR!";
        }    
    }

}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NinjaInterfaces
{
    public class Cannon : IWeapon
    {
        public int Damage { get; set; }

        public String Output()
        {
            return "Shoots cannon balls!";
        }
    }
}
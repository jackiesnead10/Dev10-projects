﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NinjaInterfaces
{
    public class Axe : IWeapon
    {
        public int Damage { get; set; }

        public string Output()
        {
            return "Can slice through walls!";
        }
    }
}

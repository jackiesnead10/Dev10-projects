﻿using System;
using System.Collections.Generic;


namespace NinjaInterfaces

{

    public class PhilosophersStone : IWeapon
    {
        public int Damage { get; set; }

        public string Output()
        {
            return "another soul has been added to the stone's collection";
        }



    }



}
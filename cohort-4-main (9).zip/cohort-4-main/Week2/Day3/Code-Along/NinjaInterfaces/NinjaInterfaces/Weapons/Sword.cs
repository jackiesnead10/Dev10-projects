﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NinjaInterfaces
{
    public class Sword : IWeapon
    {
        public int Damage { get; set; }
        public string Output()
        {
            return "Slice and Dice!";
        }
    }
}

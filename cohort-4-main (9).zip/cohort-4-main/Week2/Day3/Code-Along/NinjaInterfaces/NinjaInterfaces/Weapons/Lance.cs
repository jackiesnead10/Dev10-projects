﻿using System;

namespace NinjaInterfaces
{
    public class Lance : IWeapon
    {
        public int Damage { get; set; }

        public string Output()
        {
            return "You stick them with your pointy-er stick.";
        }
    }
}
using System;
using System.Collections.Generic;
using System.Text;

namespace NinjaInterfaces
{
    public class Spoon : IWeapon
    {
       public int Damage { get; set; }

       public string Output()
       {
           return "Not the best weapon choice.";
       }
    }
}
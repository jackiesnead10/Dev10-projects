﻿using System;
using System.Collections.Generic;
using NinjaInterfaces;

namespace NinjaInterfaces
{
    public class DoomRAYY : IWeapon
    {
        public int Damage { get;set;}

        public string Output ()
        {
            return "I'm FirRInG MaH LAzzaahhhhhHH.";
        }
    }
}

        


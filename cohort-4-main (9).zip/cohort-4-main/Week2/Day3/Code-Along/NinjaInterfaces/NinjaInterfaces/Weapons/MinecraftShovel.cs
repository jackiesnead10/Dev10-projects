﻿using System;

namespace NinjaInterfaces
{
    public class MinecraftShovel : IWeapon
    {
        public int Damage { get; set; }
        public int Duribility { get; set; }
        private bool _isBroken;

        public MinecraftShovel() 
        {
            Duribility = 100;
            Damage = 5;
            _isBroken = false;
        }

        public string Output() 
        {
            return "This is a shovel, it can be used for combat and digging!";
        }
        
        // Shovels can also dig!
        public void Dig(string ToDig) 
        {
            if (!_isBroken) 
            {
                // Get some dirt
                Console.Write("You dug up some ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write(ToDig);
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("!");

                // use a duribility
                Duribility--;

                if (Duribility <= 0) 
                {
                    _isBroken = true;
                }
            }
        }
    }
}
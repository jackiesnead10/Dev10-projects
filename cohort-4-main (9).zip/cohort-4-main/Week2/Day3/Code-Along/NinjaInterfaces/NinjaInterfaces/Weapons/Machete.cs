﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NinjaInterfaces
{
    public class Machete : IWeapon
    {
        public int Damage { get ; set ; }
        public string Output() 
        {
            return "Machete did damage!";
        }
    }
}
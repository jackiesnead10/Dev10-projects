﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NinjaInterfaces
{
    public interface IToken
    {
        int Health { get; set; }
        int Power { get;set; }
    }
}

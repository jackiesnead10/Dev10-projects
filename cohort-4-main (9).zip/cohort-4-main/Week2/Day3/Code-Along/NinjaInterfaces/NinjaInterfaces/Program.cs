﻿using System;
using System;

namespace NinjaInterfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ninja naruto = new Ninja();
            
            //GunSlinger vash = new GunSlinger();
            Sword myAwesomeSword = new Sword();
            myAwesomeSword.Damage = 100;
            
            IFighter[] fighters = new IFighter[2];
            fighters[0] = new Ninja(new DoomRAYY());
            fighters[1] = new GunSlinger();


            


            foreach (IFighter fighter in fighters)
            {
                DoDamage(fighter);

            }
        }

        static void DoDamage(IFighter fighter)
        {
            if (fighter is Ninja)
            {
                Ninja n = (Ninja) fighter;
                n.WalkOnWater();
            }
            
            Console.WriteLine(fighter.Attack());
        }
    }
}

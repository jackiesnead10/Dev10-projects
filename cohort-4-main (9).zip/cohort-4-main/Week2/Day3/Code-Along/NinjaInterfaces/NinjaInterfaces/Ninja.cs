﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NinjaInterfaces
{
    public class Ninja : IFighter, IToken
    {
        public IWeapon Weapon { get; private set; }

        public Ninja(IWeapon weapon)
        {
            Weapon = weapon;
        }
        public int Attack()
        {
            Console.WriteLine(Weapon.Output());
            return Weapon.Damage;
        }

        public void WalkOnWater()
        {
            Console.WriteLine("Walks on water! Woah!");
        }

        public int Health { get; set; }
        public int Power { get; set; }
    }
}

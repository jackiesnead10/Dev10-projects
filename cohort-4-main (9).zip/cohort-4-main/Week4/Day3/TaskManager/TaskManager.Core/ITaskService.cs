﻿using System.Collections.Generic;
using TaskManager.Core;

namespace TaskManager.Core
{
    public interface ITaskService
    {
        Result CreateTask(Task task);
        List<Task> ReadAllTasks();
        Result ReadTaskById(int id);
    }
}
﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using TaskManager.Core;

namespace TaskManager.DAL
{
    public class JSONFileTaskRepository : ITaskRepository
    {
        private string _fileName;
        private List<Task> _tasks;
        private ILogger _logger;
        public JSONFileTaskRepository(string fileName, ILogger logger)
        {
            _fileName = fileName;
            _tasks = new List<Task>();
            LoadTasks();
            _logger = logger;
        }

        private void LoadTasks()
        {
            if (!File.Exists(_fileName))
            {
                File.Create(_fileName).Close();
            }
            else
            {
                using (StreamReader sr = new StreamReader(_fileName))
                {
                    // ID, TItle, Created, Completed
                    // 1,Find Diamonds,1/1/2021,4/14/2021
                    // fields[0] = "1"
                    // fields[1] = "Find Diamonds"
                    // fields[2] = "1/1/2021"
                    // fields[3] = "1/1/2021"
                    string data = sr.ReadToEnd();
                    List<Task> tasks =  JsonConvert.DeserializeObject<List<Task>>(data);
                    if(tasks == null)
                    {
                        tasks = new List<Task>();
                    }
                    _tasks = tasks;
                }
            }
        }


        private void SaveTasks()
        {
            if (File.Exists(_fileName))
            {
                using (StreamWriter sw = new StreamWriter(_fileName))
                {

                    string output = JsonConvert.SerializeObject(_tasks, Formatting.Indented);
                    sw.WriteLine(output);
                }
            }
        }



        public Task CreateTask(Task task)
        {
            int nextId = 0;
            foreach (var currentTask in _tasks)
            {
                if (nextId < currentTask.Id)
                {
                    nextId = currentTask.Id;
                }
            }

            nextId++;
            task.Id = nextId;
            _tasks.Add(task);
            SaveTasks();
            return task;
        }



        public List<Task> ReadAllTasks()
        {
            return _tasks;
        }

        public Task ReadTaskById(int id)
        {
            foreach (var task in _tasks)
            {
                if (id == task.Id)
                {
                    return task;
                }
            }
            return null;
        }

        public void UpdateTask(int id, Task task)
        {
            for (var i = 0; i < _tasks.Count; i++)
            {
                var currentTask = _tasks[i];
                if (id == currentTask.Id)
                {
                    _tasks[i] = task;
                    SaveTasks();
                    break;
                }
            }

        }

        public void DeleteTask(int id)
        {
            int index = -1;
            for (var i = 0; i < _tasks.Count; i++)
            {
                var currentTask = _tasks[i];
                if (id == currentTask.Id)
                {
                    index = i;
                    break;
                }
            }

            if (index >= 0)
            {
                _tasks.RemoveAt(index);
                SaveTasks();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using TaskManager.Core;
using TaskManager.DAL;
namespace TaskManager.BLL
{
    public class TaskService : ITaskService
    {
        private ITaskRepository _taskRepository;
        private ILogger _logger;

        public TaskService(ITaskRepository taskRepository, ILogger logger)
        {
            _taskRepository = taskRepository;
            _logger = logger;
        }

        public Result CreateTask(Task task)
        {
            //TODO: Put in validation for Tasks
            Result result = new Result();

            if (string.IsNullOrEmpty(task.Title))
            {
                result.Message = "Task Title is required";
                result.Success = false;
                return result;
            }

            result.Success = true;
            result.Message = "Created Task Successfully";
            _taskRepository.CreateTask(task);
            return result;
        }

        public List<Task> ReadAllTasks()
        {
            return _taskRepository.ReadAllTasks();
        }

        public Result ReadTaskById(int id)
        {
            Task task = _taskRepository.ReadTaskById(id);
            Result result = new Result();
            if (task == null)
            {
                result.Success = false;
                result.Message = $"Task Id: {id} was not found";
            }
            else
            {
                result.Success = true;
                result.Data = task;
            }
            return result;
        }
    }
}

﻿using NUnit.Framework;
using System;
using TaskManager.DAL;
using TaskManager.Core;
using System.IO;
using System.Collections.Generic;

namespace TaskManager.Tests
{
    [TestFixture]
    public class FileTaskRepositoryTests
    {
        private string fileName = "testTask.csv";
        private ILogger logger;

        [SetUp]
        public void Setup()
        {
            File.Copy("task.csv", fileName, true);
            logger = new NullLogger();
        }

        public void ShouldCreateNewFileFromConstructor()
        {
            var fileTaskRepository = new FileTaskRepository("tasks.csv",logger);
            List<Task> tasks = fileTaskRepository.ReadAllTasks();

            Assert.AreEqual(0,tasks);
            Assert.IsTrue(File.Exists("newTestTasks.csv"));
            File.Delete("newTestTasks.csv");

        }
        public void ShouldLoadTasksFromExistingFile()
        {
            var fileTaskRepository = new FileTaskRepository("seedTasks.csv",logger);
            List<Task> tasks = fileTaskRepository.ReadAllTasks();

            Assert.AreEqual(1,tasks);

        }
        [Test]
        public void ShouldCreateNewTask()
        {
            // Arrange
            var fileTaskRepository = new FileTaskRepository(fileName,logger);
            Task task = new Task()
            {
                Title = "Dig down to bedrock",
                Created = DateTime.Parse("4/20/21"),
                Completed = DateTime.Parse("4/21/21"),

            };

            // Act
            fileTaskRepository.CreateTask(task);

            List<Task> tasks = fileTaskRepository.ReadAllTasks();
            // Assert
            Assert.AreEqual(2, tasks[^1].Id);
            Assert.AreEqual(tasks[^1], task);
        }

        [Test]
        public void ShouldReadAllRecords()
        {
            // Arrange
            var fileTaskRepository = new FileTaskRepository(fileName,logger);
            Task task = new Task()
            {
                Id = 1,
                Title = "Find Diamonds",
                Completed = DateTime.Parse("1/1/0001"),
                Created = DateTime.Parse("4/14/2021"),

            };
            // Act
            var result = fileTaskRepository.ReadAllTasks();

            // Assert
            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(result[0], task);

        }

        [Test]
        public void ShouldRetrieveATask()
        {
            // Arrange
            var fileTaskRepository = new FileTaskRepository(fileName,logger);
            int id = 1;
            Task task = new Task()
            {
                Id = 1,
                Title = "Find Diamonds",
                Completed = DateTime.Parse("1/1/0001"),
                Created = DateTime.Parse("4/14/2021"),

            };
            // Act
            Task found = fileTaskRepository.ReadTaskById(id);

            // Assert
            Assert.AreEqual(found, task);
        }

        [Test]
        public void ShouldUpdateTask()
        {
            // Arrange
            var fileTaskRepository = new FileTaskRepository(fileName,logger);
            int id = 1;
            Task task = new Task()
            {
                Id = 1,
                Title = "Diamondssss!",
                Completed = DateTime.Parse("1/1/0001"),
                Created = DateTime.Parse("4/14/2021"),

            };
            // Act
            Task found = fileTaskRepository.ReadTaskById(id);
            found.Title = "Diamondssss!";
            fileTaskRepository.UpdateTask(id, found);
            found = fileTaskRepository.ReadTaskById(id);

            // Assert
            Assert.AreEqual(found, task);
        }

        [Test]
        public void ShouldDeleteTask()
        {
            // Arrange
            var fileTaskRepository = new FileTaskRepository(fileName,logger);
            int id = 1;

            // Act
            fileTaskRepository.DeleteTask(id);
            Task found = fileTaskRepository.ReadTaskById(id);

            // Assert
            Assert.IsNull(found);
        }
    }
}

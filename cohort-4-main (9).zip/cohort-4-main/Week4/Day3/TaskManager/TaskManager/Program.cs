﻿using Ninject;
using System;

namespace TaskManager
{

    /// <summary>
    ///  Create a Task Manager, that will help us complete and track our tasks. We should see how long each task is taking us!
    /// </summary>
    public class Program
    {
        static void Main(string[] args)
        {

            ApplicationMode mode = (ApplicationMode)(ConsoleIO.PromptInt("1. Live\n2.Test\n3. JSON\nEnter A Choice [1-3]", 1, 3) - 1);
            NinjectContainer.Configure(mode);
            TaskManagerController controller = NinjectContainer.Kernel.Get<TaskManagerController>();
            controller.Run();

        }
    }
}

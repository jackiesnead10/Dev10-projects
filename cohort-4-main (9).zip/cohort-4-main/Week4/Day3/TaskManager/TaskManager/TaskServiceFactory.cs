﻿using TaskManager.BLL;
using TaskManager.Core;
using TaskManager.DAL;

namespace TaskManager
{
    public static class TaskServiceFactory
    {
        public static TaskService GetTaskService(ApplicationMode mode)
        {
            TaskService taskService;
            ILogger logger = new NullLogger();
            switch (mode)
            {
                case ApplicationMode.JSON:
                    ITaskRepository taskRepository = new FileTaskRepository("task.csv", logger);
                    taskService = new TaskService(taskRepository, logger);
                    return taskService;

                case ApplicationMode.Test:
                default:
                    ITaskRepository mockTaskRepository = new TaskRepository();
                    taskService = new TaskService(mockTaskRepository, logger);
                    return taskService;
            }
        }
    }
}

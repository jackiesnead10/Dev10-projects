﻿using Ninject;
using TaskManager.BLL;
using TaskManager.Core;
using TaskManager.DAL;

namespace TaskManager
{
    public static class NinjectContainer
    {
        public static StandardKernel Kernel {get; private set;}

        public static void Configure(ApplicationMode mode)
        {
            Kernel = new StandardKernel();
            Kernel.Bind<ILogger>().To<NullLogger>();
            switch (mode)
            {
                case ApplicationMode.JSON:
                    Kernel.Bind<ITaskRepository>().To<JSONFileTaskRepository>().WithConstructorArgument("fileName", "task.json");
                    break;
                case ApplicationMode.LIVE:
                    Kernel.Bind<ITaskRepository>().To<FileTaskRepository>().WithConstructorArgument("fileName", "task.csv");
                    break;
                case ApplicationMode.Test:
                    Kernel.Bind<ITaskRepository>().To<TaskRepository>();
                    break;
                default:
                    break;
            }
            Kernel.Bind<ITaskService>().To<TaskService>();
        }
    }
}

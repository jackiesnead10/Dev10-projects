﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TaskManager.BLL;
using TaskManager.Core;

namespace TaskManager
{
    public class TaskManagerController
    {
        private ITaskService _taskService;

        public TaskManagerController(ITaskService taskService)
        {
            _taskService = taskService;
        }
        public void Run()
        {
            // Keep the application running, display a menu for CRUD of tasks
            do
            {


                int choice = ConsoleIO.PromptInt("0. Exit\n1. Create Task\n2. Read All\n3. Find Task", 0, 3);
                switch (choice)
                {
                    case 0:
                        ConsoleIO.Display("Good bye");
                        return;
                    case 1:
                        CreateTask();
                        break;
                    case 2:
                        DisplayTasks();
                        break;
                    case 3:
                        FindTask();
                        break;
                }
            } while (true);
        }

        private void FindTask()
        {
            int taskId = ConsoleIO.PromptInt("Enter Task Id:");
            Result result = _taskService.ReadTaskById(taskId);
            if (result.Success)
            {
                ConsoleIO.DisplayTask(result.Data);
            }
            else
            {
                ConsoleIO.DisplayError(result.Message);
            }
        }

        private void DisplayTasks()
        {

            List<Task> tasks = _taskService.ReadAllTasks();
            ConsoleIO.DisplayTasks(tasks);

        }

        private void CreateTask()
        {
            Task task = ConsoleIO.PromptUserTask("Create New Task");
            Result result = _taskService.CreateTask(task);
            if (result.Success)
            {
                ConsoleIO.Display(result.Message);
            }
            else
            {
                ConsoleIO.DisplayError(result.Message);
            }
        }
    }
}

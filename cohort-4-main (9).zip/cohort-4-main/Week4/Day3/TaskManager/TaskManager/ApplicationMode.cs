﻿namespace TaskManager
{
    public enum ApplicationMode
    {
        LIVE,
        Test,
        JSON,
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PeopleAndPets
{
    public class Person
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime Dob { get; set; }
        public decimal Salary { get; set; }
        public string EmailAddress { get; set; }
        public string Country { get; set; }
        public IEnumerable<Pet> Pets { get; set; }

        public override bool Equals(object obj)
        {
            return obj is Person person &&
                   Id == person.Id &&
                   FirstName == person.FirstName &&
                   LastName == person.LastName &&
                   Dob == person.Dob &&
                   Salary == person.Salary &&
                   EmailAddress == person.EmailAddress &&
                   Country == person.Country &&
                   EqualityComparer<IEnumerable<Pet>>.Default.Equals(Pets, person.Pets);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Id, FirstName, LastName, Dob, Salary, EmailAddress, Country, Pets);
        }

        public override string ToString()
        {
            return $"Person(Id:{Id},{FirstName},{LastName},Dob:{Dob:yyyy-MM-dd},"
                + $"Salary:{Salary:0.00},{EmailAddress},{Country},"
                + $"Pets:[{string.Join(",", Pets.Select(p => p.ToString()))}])";

        }
    }
}

package org.swg.lambdasandstreams;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws IOException {

        PersonDataStore ds = new PersonDataStore();
        List<Person> people = ds.all();

        int allPetCount = people.stream()
                .collect(Collectors.summingInt(p -> p.getPets().size()));

        Map<String, Integer> map = people.stream()
                .collect(
                        Collectors.groupingBy(
                                p -> p.getCountry(),
                                Collectors.summingInt(p -> p.getPets().size())
                        )
                );

        // partitioning people by country
//        Map<String, List<Person>> map = people.stream()
//                .collect(Collectors.groupingBy(p -> p.getCountry()));
        System.out.println("");

        // map to new type and filter
//        people.stream()
//                .map(p -> new PersonSummary(p))
//                .filter(ps -> ps.getPetCount() > 1)
//                .forEach(System.out::println);
        // people with a first name that matches any pet name
//        List<Pet> allPets = people.stream()
//                .flatMap(p -> p.getPets().stream())
//                .collect(Collectors.toList());
//        
//        people.stream()
//                .filter(person -> allPets.stream()
//                        .anyMatch(pet -> pet.getName().equalsIgnoreCase(person.getFirstName())))
//                .forEach(System.out::println);
// people with the same first name as their pet
//         people.stream()
//                .filter(person -> person.getPets().stream()
//                        .anyMatch(pet -> pet.getName().equalsIgnoreCase(person.getFirstName())))
//                .forEach(System.out::println);
//        people.stream()
//                .flatMap(p -> p.getPets().stream())
//                .filter(pet -> pet.getPetType() == PetType.GUINEA_PIG)
//                .sorted((a, b) -> a.getName().compareTo(b.getName()))
//                .forEach(System.out::println);
//        boolean lastNameWithX = people.stream()
//                .allMatch(p -> p.getLastName().startsWith("A"));
//        
//        System.out.println("Anyone with X?: " + lastNameWithX);
        // people with only pigeons or hamsters
//        people.stream()
//                .filter(p -> !p.getPets().isEmpty()
//                    && p.getPets().stream()
//                            .allMatch(pet -> pet.getPetType() == PetType.PIGEON 
//                                    || pet.getPetType() == PetType.HAMSTER))
//                .forEach(System.out::println);
        // people with pets
//        people.stream()
//                .filter(p -> !p.getPets().isEmpty())
//                .forEach(System.out::println);
//        people.stream()
//                //.map(p -> p.getPets().isEmpty() ? null : p.getPets().get(0))  
//                .map(p -> p.getPets().stream().findFirst().orElse(null))
//                .forEach(System.out::println);
        // map to LocalDate
//        people.stream()
//                .filter(p -> p.getLastName().startsWith("A"))
//                .sorted((a, b) -> a.getFirstName().compareTo(b.getFirstName()))
//                .map(p -> p.getBirthDate())
//                .forEach(System.out::println);
    }
}

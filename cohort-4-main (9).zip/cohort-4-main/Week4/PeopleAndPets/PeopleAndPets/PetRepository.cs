﻿using System;

namespace PeopleAndPets
{
    public class PetRepository : FileRepository<Pet>
    {
        public PetRepository() : base("pets.csv", 3, true) { }

        protected override Pet Deserialize(string[] fields)
        {
            return new Pet
            {
                Name = fields[0],
                PetType = Enum.Parse<PetType>(fields[1].Replace("_", ""), true),
                PersonId = int.Parse(fields[2])
            };
        }
    }
}

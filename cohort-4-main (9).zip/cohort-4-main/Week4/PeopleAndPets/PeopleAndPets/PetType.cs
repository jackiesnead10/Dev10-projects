﻿namespace PeopleAndPets
{
    public enum PetType
    {
        Dog, 
        Cat, 
        Hamster, 
        BoaConstrictor, 
        GuineaPig, 
        Pigeon
    }
}

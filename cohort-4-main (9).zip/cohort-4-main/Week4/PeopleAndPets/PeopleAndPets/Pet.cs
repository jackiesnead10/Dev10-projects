﻿using System;

namespace PeopleAndPets
{
    public class Pet
    {
        public string Name { get; set; }
        public PetType PetType { get; set; }
        public int PersonId { get; set; }

        public override bool Equals(object obj)
        {
            return obj is Pet pet &&
                   Name == pet.Name &&
                   PetType == pet.PetType &&
                   PersonId == pet.PersonId;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Name, PetType, PersonId);
        }

        public override string ToString()
        {
            return $"Pet({Name},{PetType})";
        }
    }
}

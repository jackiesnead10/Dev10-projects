﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PeopleAndPets
{
    public class PersonRepository : FileRepository<Person>
    {
        private readonly Dictionary<int, IEnumerable<Pet>> petMap;

        public PersonRepository() : base("people.csv", 7, true)
        {
            var petRepo = new PetRepository();
            petMap = petRepo.FindAll()
                .GroupBy(p => p.PersonId)
                .ToDictionary(g => g.Key, g => g.AsEnumerable());
        }

        protected override Person Deserialize(string[] fields)
        {
            Person p = new Person();
            p.Id = int.Parse(fields[0]);
            p.FirstName = fields[1];
            p.LastName = fields[2];
            p.EmailAddress = fields[3];
            p.Country = fields[4];
            p.Dob = DateTime.Parse(fields[5]);
            p.Salary = decimal.Parse(fields[6]);
            if(petMap.ContainsKey(p.Id))
            {
                p.Pets = petMap[p.Id];
            }
            else
            {
                p.Pets = new List<Pet>();
            }
            return p;
        }
    }
}

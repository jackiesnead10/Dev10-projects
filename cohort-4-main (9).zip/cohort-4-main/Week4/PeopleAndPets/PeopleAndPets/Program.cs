﻿using System;

namespace PeopleAndPets
{
    class Program
    {
        static void Main(string[] args)
        {
            var repo = new PersonRepository();
            foreach(var person in repo.FindAll())
            {
                Console.WriteLine(person);
            }

           
        }
    }
}

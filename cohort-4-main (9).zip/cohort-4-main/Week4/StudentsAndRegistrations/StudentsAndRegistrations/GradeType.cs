﻿namespace StudentsAndRegistrations
{
    public enum GradeType
    {
        AThroughF,
        PassFail,
        Audit
    }
}

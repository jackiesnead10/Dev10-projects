﻿using System;

namespace StudentsAndRegistrations
{
    public class Registration
    {
        public string Course { get; set; }
        public decimal PointPercent { get; set; }
        public GradeType GradeType { get; set; }

        public override bool Equals(object obj)
        {
            return obj is Registration registration &&
                   Course == registration.Course &&
                   PointPercent == registration.PointPercent &&
                   GradeType == registration.GradeType;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Course, PointPercent, GradeType);
        }
        public override string ToString()
        {
            return $"Registration({Course},Point %:{PointPercent:0.00},{GradeType})";
        }
    }
}

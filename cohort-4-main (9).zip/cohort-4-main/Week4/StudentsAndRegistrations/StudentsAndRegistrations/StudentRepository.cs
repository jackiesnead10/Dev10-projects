﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace StudentsAndRegistrations
{
    public class StudentRepository : FileRepository<Student>
    {
        public StudentRepository() : base("students.csv", 8, true) { }

        protected override Student Deserialize(string[] fields)
        {
            Student student = new Student
            {
                Id = int.Parse(fields[0]),
                FirstName = fields[1],
                LastName = fields[2],
                EmailAddress = fields[3],
                Dob = DateTime.Parse(fields[4]),
                Country = fields[5],
                Gpa = decimal.Parse(fields[6]),
                Major = GetMajor(int.Parse(fields[7])),
                Iq = (decimal)(80.0 + random.NextDouble() * 50.0)
            };
            SetRegistrations(student);

            return student;
        }

        string GetMajor(int id) => id switch
        {
            1 => "American Studies",
            2 => "Sociology",
            3 => "Philosophy",
            4 => "Political Science",
            5 => "Economics",
            6 => "Business",
            7 => "Anthropology",
            8 => "Education",
            9 => "Communications",
            10 => "Pre-Med",
            11 => "Mathematics",
            _ => "Computer Science"
        };

        private string[] courses = new string[]
        {
            "Research Methods: Research in Liberal Arts Disciplines",
            "Greco-Roman Tradition",
            "Ancient Philosophy",
            "Sacred Writing",
            "Intro to College English",
            "World Views",
            "Post-Classical History",
            "Modern Philosophy",
            "Principles of Mathematics and Logic",
            "Renaissance to Baroque Art",
            "Literary Genres",
            "Modern History-19th and 20th Centuries",
            "Science: History and Methodology",
            "Literary Themes",
            "Knowledge",
            "Applied Themes in English",
            "Applied Ethics in Humanities",
            "Physical Activity and Autonomy"
        };

        private void SetRegistrations(Student student)
        {
            GradeType[] gradeTypes = Enum.GetValues<GradeType>();
            HashSet<string> registeredCourses = new HashSet<string>();
            List<Registration> registrations = new List<Registration>();

            int count = random.Next(4) + 2;
            while(registeredCourses.Count < count)
            {
                registeredCourses.Add(courses[random.Next(courses.Length)]);
            }

            student.Registrations = registeredCourses.Select(course => new Registration
            {
                Course = course,
                GradeType = gradeTypes[random.Next(gradeTypes.Length)],
                PointPercent = 75 + random.Next(25)
            }).ToList();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;

namespace StudentsAndRegistrations
{
    public abstract class FileRepository<T>
    {
        private const int RAND_SEED = 97531;
        private readonly string filePath;
        private readonly int columnCount;
        private readonly bool hasHeaders;

        protected Random random = new Random(RAND_SEED);

        public FileRepository(string filePath, int columnCount, bool hasHeaders)
        {
            string projectDirectory = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName;
            this.filePath = Path.Combine(projectDirectory, filePath);
            this.columnCount = columnCount;
            this.hasHeaders = hasHeaders;
        }

        public IEnumerable<T> FindAll()
        {
            random = new Random(RAND_SEED);
            string[] lines = File.ReadAllLines(filePath);
            for(int i = hasHeaders ? 1 : 0; i < lines.Length; i++)
            {
                string[] fields = lines[i].Split(",", StringSplitOptions.TrimEntries);
                if(fields.Length == columnCount)
                {
                    yield return Deserialize(fields);
                }
            }
        }

        protected abstract T Deserialize(string[] fields);
    }

}

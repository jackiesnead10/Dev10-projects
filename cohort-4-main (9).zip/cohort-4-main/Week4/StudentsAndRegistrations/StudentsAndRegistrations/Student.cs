﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace StudentsAndRegistrations
{
    public class Student
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public DateTime Dob { get; set; }
        public string Country { get; set; }
        public decimal Gpa { get; set; }
        public string Major { get; set; }
        public decimal Iq { get; set; }
        public IEnumerable<Registration> Registrations { get; set; }

        public override bool Equals(object obj)
        {
            return obj is Student student &&
                   Id == student.Id &&
                   FirstName == student.FirstName &&
                   LastName == student.LastName &&
                   EmailAddress == student.EmailAddress &&
                   Dob == student.Dob &&
                   Country == student.Country &&
                   Gpa == student.Gpa &&
                   Major == student.Major &&
                   Iq == student.Iq &&
                   EqualityComparer<IEnumerable<Registration>>.Default.Equals(Registrations, student.Registrations);
        }

        public override int GetHashCode()
        {
            HashCode hash = new HashCode();
            hash.Add(Id);
            hash.Add(FirstName);
            hash.Add(LastName);
            hash.Add(EmailAddress);
            hash.Add(Dob);
            hash.Add(Country);
            hash.Add(Gpa);
            hash.Add(Major);
            hash.Add(Iq);
            hash.Add(Registrations);
            return hash.ToHashCode();
        }

        public override string ToString()
        {
            return $"Student(Id:{Id},{FirstName},{LastName},{EmailAddress},Dob:{Dob:yyyy-MM-dd},"
                + $"Country:{Country},Gpa:{Gpa:0.00},Major:{Major},Iq:{Iq:0.0},"
                + $"Registrations:[{string.Join(",", Registrations.Select(r => r.ToString()))}])";
        }
    }
}

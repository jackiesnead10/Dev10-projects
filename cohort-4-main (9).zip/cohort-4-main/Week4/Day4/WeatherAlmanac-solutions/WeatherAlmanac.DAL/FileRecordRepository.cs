﻿using System;
using System.Collections.Generic;
using System.IO;
using WeatherAlmanac.Core;

namespace WeatherAlmanac.DAL
{
    public class FileRecordRepository : IRecordRepository
    {
        private List<DateRecord> _records;
        private readonly string FILENAME;
        public FileRecordRepository(string fileName)
        {
            FILENAME = fileName;
            LoadRecords();
        }
        private DateRecord MapToObject(string row)
        {
            DateRecord dateRecord = new DateRecord();
            string[] fields = row.Split(',');
            dateRecord.Date = DateTime.Parse(fields[0]);
            dateRecord.HighTemp = decimal.Parse(fields[1]);
            dateRecord.LowTemp = decimal.Parse(fields[2]);
            dateRecord.Humidity = decimal.Parse(fields[3]);
            dateRecord.Description = fields[3].Replace("||", ",");
            return dateRecord;
        }
        private void LoadRecords()
        {
            if (!File.Exists(FILENAME))
            {
                File.Create(FILENAME).Close();
                return;
            }
            using (StreamReader sr = new StreamReader(FILENAME))
            {
                string row = null;
                while ((row = sr.ReadLine()) != null)
                {
                    _records.Add(MapToObject(row));
                }
            }
        }
        private void SaveRecords()
        {
            if (!File.Exists(FILENAME))
            {
                File.Create(FILENAME).Close();
            }
            using (StreamWriter sw = new StreamWriter(FILENAME))
            {
                foreach (DateRecord record in _records)
                {
                    sw.WriteLine($"{record.Date.ToString("mmddyyyy")},{record.HighTemp},{record.LowTemp},{record.Humidity},{record.Description.Replace(",", "||")}");
                }
            }
        }
        public Result<List<DateRecord>> GetAll()
        {
            return new Result<List<DateRecord>>() { Data = _records };
        }

        public Result<DateRecord> Add(DateRecord record)
        {
            _records.Add(record);
            SaveRecords();
            return new Result<DateRecord> { Success = true, Message = "Successfully added record" };
        }

        public Result<DateRecord> Remove(DateTime date)
        {
            Result<DateRecord> result = new Result<DateRecord>();
            for (int i = 0; i < _records.Count; i++)
            {
                if (_records[i].Date == date)
                {
                    result.Data = _records[i];
                    result.Success = true;
                    _records.RemoveAt(i);
                    SaveRecords();
                    return result;
                }
            }
            result.Success = false;
            return result;
        }

        public Result<DateRecord> Edit(DateRecord record)
        {
            Result<DateRecord> result = new Result<DateRecord>();
            for (int i = 0; i < _records.Count; i++)
            {
                if (_records[i].Date == record.Date)
                {
                    _records[i] = record;
                    result.Success = true;
                    SaveRecords();
                    return result;
                }
            }
            result.Success = false;
            result.Message = "Unable to locate record";
            return result;
        }
    }
}

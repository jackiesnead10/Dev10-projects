﻿using System;
using System.Collections.Generic;
using System.Text;
using WeatherAlmanac.Core;

namespace WeatherAlmanac.DAL
{
    public class MockRecordRepository : IRecordRepository
    {
        private List<DateRecord> _records; // private field to store data records

        public MockRecordRepository()
        {
            // todo: instantiate _records and populate with sample data
            _records = new List<DateRecord>();
            _records.Add(new DateRecord()
            {
                Date = DateTime.Parse("1/1/2021"),
                HighTemp = 10,
            });
        }

        public Result<List<DateRecord>> GetAll()
        {
            return new Result<List<DateRecord>>() { Data = _records };
        }

        public Result<DateRecord> Add(DateRecord record)
        {
            _records.Add(record);
            return new Result<DateRecord> { Success = true, Message = "Successfully added record" };
        }

        public Result<DateRecord> Remove(DateTime date)
        {
            Result<DateRecord> result = new Result<DateRecord>();
            for (int i = 0; i < _records.Count; i++)
            {
                if (_records[i].Date == date)
                {
                    result.Data = _records[i];
                    result.Success = true;
                    _records.RemoveAt(i);
                    return result;
                }
            }
            result.Success = false;
            return result;
        }

        public Result<DateRecord> Edit(DateRecord record)
        {
            Result<DateRecord> result = new Result<DateRecord>();
            for (int i = 0; i < _records.Count; i++)
            {
                if (_records[i].Date == record.Date)
                {
                    _records[i] = record;
                    result.Success = true;
                    return result;
                }
            }
            result.Success = false;
            result.Message = "Unable to locate record";
            return result;
        }
    }
}

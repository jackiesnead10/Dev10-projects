﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.IO;
using WeatherAlmanac.Core;

namespace WeatherAlmanac.DAL
{
    public class JsonFileRecordRepository : IRecordRepository
    {
        private List<DateRecord> _records;
        private readonly string FILENAME;
        public JsonFileRecordRepository(string fileName)
        {
            FILENAME = fileName;
            LoadRecords();
        }
        private DateRecord MapToObject(string row)
        {
            return JsonConvert.DeserializeObject<DateRecord>(row);
        }
        private void LoadRecords()
        {
            if (!File.Exists(FILENAME))
            {
                File.Create(FILENAME).Close();
                return;
            }
            using (StreamReader sr = new StreamReader(FILENAME))
            {
                string row = null;
                while ((row = sr.ReadLine()) != null)
                {
                    _records.Add(MapToObject(row));
                }
            }
        }
        private void SaveRecords()
        {
            if (!File.Exists(FILENAME))
            {
                File.Create(FILENAME).Close();
            }
            JsonSerializer serializer = new JsonSerializer();
            serializer.Converters.Add(new JavaScriptDateTimeConverter());
            serializer.NullValueHandling = NullValueHandling.Ignore;
            using (StreamWriter sw = new StreamWriter(FILENAME))
            using (JsonWriter writer = new JsonTextWriter(sw))
            {
                serializer.Serialize(writer, _records);
            }
        }
        public Result<List<DateRecord>> GetAll()
        {
            return new Result<List<DateRecord>>() { Data = _records };
        }

        public Result<DateRecord> Add(DateRecord record)
        {
            _records.Add(record);
            SaveRecords();
            return new Result<DateRecord> { Success = true, Message = "Successfully added record" };
        }

        public Result<DateRecord> Remove(DateTime date)
        {
            Result<DateRecord> result = new Result<DateRecord>();
            for (int i = 0; i < _records.Count; i++)
            {
                if (_records[i].Date == date)
                {
                    result.Data = _records[i];
                    result.Success = true;
                    _records.RemoveAt(i);
                    SaveRecords();
                    return result;
                }
            }
            result.Success = false;
            return result;
        }

        public Result<DateRecord> Edit(DateRecord record)
        {
            Result<DateRecord> result = new Result<DateRecord>();
            for (int i = 0; i < _records.Count; i++)
            {
                if (_records[i].Date == record.Date)
                {
                    _records[i] = record;
                    result.Success = true;
                    SaveRecords();
                    return result;
                }
            }
            result.Success = false;
            result.Message = "Unable to locate record";
            return result;
        }
    }
}

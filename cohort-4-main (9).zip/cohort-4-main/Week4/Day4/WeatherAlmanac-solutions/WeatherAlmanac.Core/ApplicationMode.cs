﻿namespace WeatherAlmanac.Core
{
    public enum ApplicationMode
    {
        LIVE,
        TEST
    }
}

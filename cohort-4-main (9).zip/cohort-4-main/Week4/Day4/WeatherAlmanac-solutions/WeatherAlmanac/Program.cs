﻿using WeatherAlmanac.BLL;
using WeatherAlmanac.Core;
using WeatherAlmanac.DAL;

namespace WeatherAlmanac.UI
{
    class Program
    {
        static void Main(string[] args)
        {
            //TODO: Create a start menu
            WeatherAlmanacController controller;
            IRecordRepository recordRepository;
            WeatherAlmanacView.DisplayHeader("Welcome to the Weather Almanac.");
            ApplicationMode mode = (ApplicationMode)WeatherAlmanacView.PromptUserInt("What mode would you like to run in?\n\n1. Live\n2. Test",1,2);
            IRecordService service = RecordServiceFactory.GetRecordService(mode);
            controller = new WeatherAlmanacController( service);
            controller.Run();
        }
    }
    public static class RecordServiceFactory
    {
        public static IRecordService GetRecordService(ApplicationMode mode)
        {
            if (mode == ApplicationMode.LIVE)
            {
                return new RecordService(new FileRecordRepository("alamanc.csv"));
            }
            else
            {
                return new RecordService(new MockRecordRepository());
            }
        }
    }
}

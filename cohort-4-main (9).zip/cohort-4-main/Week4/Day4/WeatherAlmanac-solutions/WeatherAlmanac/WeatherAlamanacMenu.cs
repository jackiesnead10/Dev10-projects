﻿namespace WeatherAlmanac.UI
{
    public enum WeatherAlamanacMenu
    {
        LOAD_RECORD = 1,
        VIEW_RECORD_BY_DATE,
        ADD_RECORD,
        EDIT_RECORD,
        DELETE_RECORD,
        QUIT
    }
}

﻿using System;
using WeatherAlmanac.BLL;
using WeatherAlmanac.Core;

namespace WeatherAlmanac.UI
{
    public class WeatherAlmanacController
    {
        private readonly IRecordService service;
        private const string MENU = "1. Load a Record\n2. View Records by Date Range\n3. Add Record\n4. Edit Record\n5. Delete Record\n6. Quit\n\nEnter Choice:";
        public WeatherAlmanacController(IRecordService service)
        {

            this.service = service;
        }
        public void Run()
        {
            bool keepRunning = true;
            while (keepRunning)
            {
                WeatherAlamanacMenu choice = (WeatherAlamanacMenu)WeatherAlmanacView.PromptUserInt(MENU, 1, 6);
                switch (choice)
                {
                    case WeatherAlamanacMenu.LOAD_RECORD:
                        LoadRecords();
                        break;
                    case WeatherAlamanacMenu.VIEW_RECORD_BY_DATE:
                        ViewRecordsByDate();
                        break;
                    case WeatherAlamanacMenu.ADD_RECORD:
                        AddRecords();
                        break;
                    case WeatherAlamanacMenu.EDIT_RECORD:
                        EditRecord();
                        break;
                    case WeatherAlamanacMenu.DELETE_RECORD:
                        DeleteRecord();
                        break;
                    case WeatherAlamanacMenu.QUIT:
                        WeatherAlmanacView.Display("Good Bye");
                        break;
                }
            }
        }
        private void LoadRecords()
        {
            WeatherAlmanacView.DisplayHeader("Load Record");
            DateTime recordDate = WeatherAlmanacView.PromptUserDate("Enter Record Date: ", DateTime.Now);
            Result<DateRecord> response = service.Get(recordDate);
            if (response.Success)
            {
                WeatherAlmanacView.DisplayRecord(response.Data);
            }
            else
            {
                WeatherAlmanacView.Display(response.Message);
            }
            WeatherAlmanacView.PromptUser("\nPress Enter to Continue.\n");
        }
        private void ViewRecordsByDate()
        {
            WeatherAlmanacView.DisplayHeader("Load Records by Date Range");
            DateTime startDate = WeatherAlmanacView.PromptUserDate("Enter Start Date: ", DateTime.Now);
            DateTime endDate = WeatherAlmanacView.PromptUserDate("Enter End Date: ", DateTime.Now);
            var response = service.LoadRange(startDate, endDate);

            if (response.Success)
            {
                WeatherAlmanacView.DisplayRecords(response.Data);
            }
            else
            {
                WeatherAlmanacView.Display(response.Message);
            }
            WeatherAlmanacView.PromptUser("\nPress Enter to Continue.\n");
        }
        private void AddRecords()
        {
            WeatherAlmanacView.DisplayHeader("Add Record");
            DateRecord dateRecord = WeatherAlmanacView.GetDateRecordInfo();
            Result<DateRecord> response = service.Add(dateRecord);
            if (response.Success)
            {
                WeatherAlmanacView.Display("Added successfuly");
            }
            else
            {
                WeatherAlmanacView.Display(response.Message);
            }
            WeatherAlmanacView.PromptUser("\nPress Enter to Continue.\n");
        }
        private void EditRecord()
        {
            WeatherAlmanacView.DisplayHeader("Edit Record");
            DateTime recordDate = WeatherAlmanacView.PromptUserDate("Enter Start Date: ", DateTime.Now);
            var response = service.Get(recordDate);

            if (response.Success)
            {
                DateRecord newInfo = WeatherAlmanacView.EditRecord(response.Data);
                service.Edit(newInfo);

            }
            else
            {
                WeatherAlmanacView.Display(response.Message);
            }
            WeatherAlmanacView.PromptUser("\nPress Enter to Continue.\n");

        }
        private void DeleteRecord()
        {
            WeatherAlmanacView.DisplayHeader("Delete Record");
            DateTime recordDate = WeatherAlmanacView.PromptUserDate("Enter Start Date: ", DateTime.Now);
            var response = service.Get(recordDate);

            if (response.Success)
            {
                service.Remove(recordDate);
            }
            else
            {
                WeatherAlmanacView.Display(response.Message);
            }
            WeatherAlmanacView.PromptUser("\nPress Enter to Continue.\n");
        }
    }
}

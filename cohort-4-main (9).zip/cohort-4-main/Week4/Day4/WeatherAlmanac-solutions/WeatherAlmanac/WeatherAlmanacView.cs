﻿using System;
using System.Collections.Generic;
using WeatherAlmanac.Core;

namespace WeatherAlmanac.UI
{
    public static class WeatherAlmanacView
    {
        public static void DisplayHeader(string header)
        {
            Display($"{header}\n");
            Display($"===============================\n");
        }
        public static void Display(string message)
        {
            Console.Write(message);
        }
        public static string PromptUser(string message)
        {
            Display(message);
            return Console.ReadLine();
        }
        public static int PromptUserInt(string message, int min, int max)
        {
            int result = 0;
            while (!(int.TryParse(PromptUser(message), out result)) || result < min || result > max)
            {
                PromptUser($"Invalid Input, must be between {min} and {max}\nPress Enter to Continue");
            }
            return result;
        }
        public static decimal PromptUserDecimal(string message, decimal min, decimal max)
        {
            decimal result = 0;
            while (!(decimal.TryParse(PromptUser(message), out result)) || result < min || result > max)
            {
                PromptUser($"Invalid Input, must be between {min} and {max}\nPress Enter to Continue");
            }
            return result;
        }
        public static decimal PromptUserDecimal(string message)
        {
            decimal result;
            while (!decimal.TryParse(PromptUser(message), out result))
            {
                Display("Invalid Input\n");
            }
            return result;
        }
        public static DateTime PromptUserDate(string message, DateTime max)
        {
            DateTime result;
            while (!(DateTime.TryParse(PromptUser(message), out result)) || result > max)
            {
                PromptUser("Invalid Input\nPress Enter to Continue");
            }
            return result;
        }

        public static void DisplayRecord(DateRecord data)
        {
            Display($"{data.Date.ToString("MMMM dd, yyyy")}\nHigh: {data.HighTemp}F\nLow: {data.LowTemp}F\nHumidity: {data.Humidity.ToString("f")} %\nDescription: {data.Description}\n");
            Display("--------------\n");
        }

        public static void DisplayRecords(List<DateRecord> data)
        {
            foreach (var item in data)
            {
                DisplayRecord(item);
            }
        }

        public static DateRecord GetDateRecordInfo()
        {
            DateTime date = PromptUserDate("Date: ", DateTime.Now);
            decimal high = PromptUserDecimal("High: ", -50, 140);
            decimal low = PromptUserDecimal("Low: ", -50, 140);
            decimal humidity = PromptUserDecimal("Humidity: ", 0, 100);
            string description = PromptUser("Description: ");
            DateRecord record = new DateRecord()
            {
                Date = date,
                HighTemp = high,
                LowTemp = low,
                Humidity = humidity,
                Description = description
            };
            return record;
        }

        public static DateRecord EditRecord(DateRecord data)
        {
            string highstr = PromptUser($"High ({data.HighTemp.ToString("f")}): ");
            var dataHighTemp = data.HighTemp;
            decimal.TryParse(highstr, out dataHighTemp);

            string lowstr = PromptUser($"Low: ({data.LowTemp.ToString("f")})");
            var dataLowTemp = data.LowTemp;
            decimal.TryParse(lowstr, out dataLowTemp);

            string humidity = PromptUser($"Humidity ({data.Humidity.ToString("f")}): ");
            decimal datahumidity = data.Humidity;
            decimal.TryParse(humidity, out datahumidity);
            Display($"Old Description: {data.Description}");
            string description = PromptUser("Description: ");
            if (string.IsNullOrEmpty(description))
            {
                description = data.Description;
            }
            DateRecord record = new DateRecord()
            {
                Date = data.Date,
                HighTemp = dataHighTemp,
                LowTemp = dataLowTemp,
                Humidity = datahumidity,
                Description = description
            };
            return record;
        }
    }
}

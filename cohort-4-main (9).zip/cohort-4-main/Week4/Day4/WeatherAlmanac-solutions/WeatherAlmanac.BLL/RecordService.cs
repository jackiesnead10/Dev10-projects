﻿using System;
using System.Collections.Generic;
using System.Text;
using WeatherAlmanac.Core;

namespace WeatherAlmanac.BLL
{
    public class RecordService : IRecordService
    {
        private IRecordRepository _repo;

        public RecordService(IRecordRepository implementation)
        {
            _repo = implementation;
        }

        public Result<List<DateRecord>> LoadRange(DateTime start, DateTime end)
        {
            // todo: check to see that start is before end date
            // todo: filter records from repository get all based on date range
            // todo: if no records found, return success false with not found message
            List<DateRecord> results = new List<DateRecord>();
            List<DateRecord> records = _repo.GetAll().Data;
            foreach (var record in records)
            {
                if (record.Date >= start && record.Date <= end)
                {
                    results.Add(record);
                }
            }
            if (results.Count == 0)
            {
                return new Result<List<DateRecord>>() { Data = results, Message = "No results found" };
            }
            return new Result<List<DateRecord>>() { Success = true, Data = results };
        }

        public Result<DateRecord> Get(DateTime date)
        {
            // todo: date cannot be in the future
            // todo: find specific date in repository data or return success false with not found message
            if (date >= DateTime.Now)
            {
                return new Result<DateRecord>() { Message = "Date Can not be in the future" };
            }
            List<DateRecord> records = _repo.GetAll().Data;
            foreach (var record in records)
            {
                if (record.Date == date)
                {
                    return new Result<DateRecord>() { Data = record, Success = true };
                }
            }
            return new Result<DateRecord>() {  Message = "No results found" };


        }

        public Result<DateRecord> Add(DateRecord record)
        {
            // todo: date cannot be in the future
            // todo: temperature range is -50 to 140
            // todo: humidity must be between 0 and 100
            if (record.Date >= DateTime.Now)
            {
                return new Result<DateRecord>() { Message = "Date Can not be in the future" };
            }
            if (record.HighTemp <= 140 && record.LowTemp >= -50)
            {
                return new Result<DateRecord>() { Message = "Temperature range must be between -50 to 140" };
            }
            if (record.Humidity <= 100 && record.Humidity >= 0)
            {
                return new Result<DateRecord>() { Message = "Humidity must be between 0 and 100" };
            }

            return _repo.Add(record);
        }

        public Result<DateRecord> Remove(DateTime date)
        {
            // todo: pass through to IRecordRepository

            return _repo.Remove(date);
        }

        public Result<DateRecord> Edit(DateRecord record)
        {
            // todo: pass through to IRecordRepository, this should only not be successful if the date doesn't exist
            // which should have been caught when retrieving the record to edit.
            return _repo.Edit(record);
        }
    }
}
